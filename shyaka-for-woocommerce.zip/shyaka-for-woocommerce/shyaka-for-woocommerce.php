<?php
/**
 * Plugin Name:          Shyaka for WooCommerce
 * Plugin URI:           https://shyaka.art/woocommerce.html
 * Description:          Show your WooCommerce products in Shyaka, the iPhone wardrobe app. Shoppers save your pieces, add them to their closet and tap Buy to reach your own checkout.
 * Version:              1.0.1
 * Requires at least:    6.3
 * Requires PHP:         7.4
 * Requires Plugins:     woocommerce
 * Author:               Shyaka
 * Author URI:           https://shyaka.art/
 * License:              GPL-2.0-or-later
 * License URI:          https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:          shyaka-for-woocommerce
 * WC requires at least: 8.0
 * WC tested up to:      11.2
 *
 * @package ShyakaForWooCommerce
 */

defined( 'ABSPATH' ) || exit;

define( 'SHYAKA_WC_VERSION', '1.0.1' );
define( 'SHYAKA_WC_FILE', __FILE__ );
define( 'SHYAKA_WC_DIR', plugin_dir_path( __FILE__ ) );
define( 'SHYAKA_WC_URL', plugin_dir_url( __FILE__ ) );

require_once SHYAKA_WC_DIR . 'includes/class-shyaka-wc-client.php';
require_once SHYAKA_WC_DIR . 'includes/class-shyaka-wc-products.php';
require_once SHYAKA_WC_DIR . 'includes/class-shyaka-wc-notices.php';
require_once SHYAKA_WC_DIR . 'includes/class-shyaka-wc-admin.php';
require_once SHYAKA_WC_DIR . 'includes/class-shyaka-wc-storefront.php';

// The plugin touches no orders and adds nothing to the cart or checkout, so it works with both of WooCommerce's newer storage and checkout options.
add_action(
	'before_woocommerce_init',
	static function () {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', SHYAKA_WC_FILE, true );
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', SHYAKA_WC_FILE, true );
		}
	}
);

add_action(
	'plugins_loaded',
	static function () {
		// The product setting is registered even without WooCommerce, so uninstalling can still find it.
		Shyaka_WC_Products::register_meta_hooks();
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}
		Shyaka_WC_Products::init();
		Shyaka_WC_Notices::init();
		Shyaka_WC_Storefront::init();
		if ( is_admin() ) {
			Shyaka_WC_Admin::init();
		}
	}
);

register_deactivation_hook( SHYAKA_WC_FILE, array( 'Shyaka_WC_Client', 'on_deactivate' ) );
