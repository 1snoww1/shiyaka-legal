<?php
/**
 * Deleting the plugin: tell Shyaka to remove the store (signed disconnect), then delete the plugin's settings and the
 * Show in Shyaka setting on every product.
 *
 * @package ShyakaForWooCommerce
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

if ( ! defined( 'SHYAKA_WC_VERSION' ) ) {
	define( 'SHYAKA_WC_VERSION', '1.0.0' );
}
require_once __DIR__ . '/includes/class-shyaka-wc-client.php';

if ( Shyaka_WC_Client::has_secret() ) {
	Shyaka_WC_Client::call( 'disconnect', array(), 8 );
}

delete_option( Shyaka_WC_Client::SECRET_OPTION );
delete_option( 'shyaka_wc_button' );
delete_post_meta_by_key( 'shyaka_listed' );

if ( function_exists( 'as_unschedule_all_actions' ) ) {
	as_unschedule_all_actions( '', array(), 'shyaka' );
}
wp_unschedule_hook( 'shyaka_wc_product_changed' );
wp_unschedule_hook( 'shyaka_wc_sync' );

// Connect errors are kept for two minutes per user; remove any left over.
global $wpdb;
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one-off clean-up while uninstalling.
$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s", $wpdb->esc_like( '_transient_shyaka_wc_' ) . '%', $wpdb->esc_like( '_transient_timeout_shyaka_wc_' ) . '%' ) );
