<?php
/**
 * Talks to Shyaka's server. Every call except connect_begin is signed with the site secret; the browser never sees it.
 *
 * Contract: docs/WOOCOMMERCE.md in the Shyaka repository.
 *  - secret      = 32 random bytes, kept as 64 lower-case hex characters in an option that is not autoloaded.
 *  - secret_hash = hex SHA-256 of that 64-character text (what connect_begin sends; all the server keeps).
 *  - signature   = hex HMAC-SHA256 of "time\nsite\nbody", keyed with secret_hash (the 64-character hex text as bytes).
 *
 * @package ShyakaForWooCommerce
 */

defined( 'ABSPATH' ) || exit;

/**
 * Signed requests to the Shyaka server.
 */
final class Shyaka_WC_Client {

	const DEFAULT_SERVER = 'https://yxxryttfcwgirxhhrdjc.supabase.co/functions/v1/woocommerce';
	const SECRET_OPTION  = 'shyaka_wc_secret';

	/**
	 * The server address. Override with the SHYAKA_SERVER_URL constant in wp-config.php or the shyaka_server_url filter
	 * (local testing only).
	 *
	 * @return string
	 */
	public static function server_url() {
		$url = defined( 'SHYAKA_SERVER_URL' ) ? (string) SHYAKA_SERVER_URL : self::DEFAULT_SERVER;
		return (string) apply_filters( 'shyaka_server_url', $url );
	}

	/**
	 * The store's identity: its home address in lower case, no trailing slash, no query.
	 *
	 * @return string
	 */
	public static function site() {
		$parts = wp_parse_url( home_url( '/' ) );
		if ( empty( $parts['host'] ) ) {
			return '';
		}
		$site = ( isset( $parts['scheme'] ) ? $parts['scheme'] : 'https' ) . '://' . $parts['host'];
		if ( ! empty( $parts['port'] ) ) {
			$site .= ':' . (int) $parts['port'];
		}
		if ( ! empty( $parts['path'] ) ) {
			$site .= $parts['path'];
		}
		return untrailingslashit( strtolower( $site ) );
	}

	/**
	 * Whether this store has a secret, i.e. has started connecting at least once.
	 *
	 * @return bool
	 */
	public static function has_secret() {
		return '' !== self::secret( false );
	}

	/**
	 * The site secret, made once when $create is true.
	 *
	 * @param bool $create Make one when there is none.
	 * @return string 64 hex characters, or '' when there is none.
	 */
	public static function secret( $create = false ) {
		$secret = get_option( self::SECRET_OPTION, '' );
		if ( is_string( $secret ) && preg_match( '/^[0-9a-f]{64}$/', $secret ) ) {
			return $secret;
		}
		if ( ! $create ) {
			return '';
		}
		$secret = bin2hex( random_bytes( 32 ) );
		delete_option( self::SECRET_OPTION );
		add_option( self::SECRET_OPTION, $secret, '', false );
		return $secret;
	}

	/**
	 * Forget the secret (after the server has dropped the connection).
	 */
	public static function forget() {
		delete_option( self::SECRET_OPTION );
	}

	/**
	 * The hex SHA-256 of the secret: sent once in connect_begin and used as the HMAC key.
	 *
	 * @param string $secret The secret.
	 * @return string
	 */
	public static function secret_hash( $secret ) {
		return hash( 'sha256', $secret );
	}

	/**
	 * The signature for one request.
	 *
	 * @param string $time Unix seconds.
	 * @param string $site The site identity.
	 * @param string $body The exact JSON body sent.
	 * @param string $secret The site secret.
	 * @return string
	 */
	public static function signature( $time, $site, $body, $secret ) {
		return hash_hmac( 'sha256', $time . "\n" . $site . "\n" . $body, self::secret_hash( $secret ) );
	}

	/**
	 * Start connecting: sends only the secret's hash and returns the server's reply (state, authorize_url).
	 *
	 * @return array|WP_Error
	 */
	public static function connect_begin() {
		$secret  = self::secret( true );
		$payload = array(
			'action'         => 'connect_begin',
			'site'           => self::site(),
			'secret_hash'    => self::secret_hash( $secret ),
			'wp_version'     => get_bloginfo( 'version' ),
			'wc_version'     => defined( 'WC_VERSION' ) ? WC_VERSION : '',
			'plugin_version' => SHYAKA_WC_VERSION,
			'checkout_url'   => function_exists( 'wc_get_checkout_url' ) ? wc_get_checkout_url() : '',
			'admin_email'    => get_option( 'admin_email' ),
			'shop_name'      => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			// Not in the contract; lets the server send the shop back to the right page when WordPress lives elsewhere.
			'return_url'     => admin_url( 'admin.php?page=shyaka' ),
		);
		return self::send( $payload, false, 20 );
	}

	/**
	 * A signed action.
	 *
	 * @param string $action The action name.
	 * @param array  $extra  Extra fields.
	 * @param int    $timeout Seconds.
	 * @return array|WP_Error
	 */
	public static function call( $action, $extra = array(), $timeout = 20 ) {
		if ( ! self::has_secret() ) {
			return new WP_Error( 'shyaka_not_connected', __( 'Connect your store to Shyaka first.', 'shyaka-for-woocommerce' ), array( 'status' => 409 ) );
		}
		return self::send( array_merge( array( 'action' => $action ), $extra ), true, $timeout );
	}

	/**
	 * Build the request: the URL, headers and body exactly as sent. Public so the plugin's tests can check signing.
	 *
	 * @param array $payload JSON body.
	 * @param bool  $signed  Add the signature headers.
	 * @return array{url:string,headers:array,body:string}
	 */
	public static function build( $payload, $signed ) {
		$body    = wp_json_encode( $payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		$headers = array(
			'Content-Type' => 'application/json',
			'Accept'       => 'application/json',
		);
		if ( $signed ) {
			$site                          = self::site();
			$time                          = (string) time();
			$headers['X-Shyaka-Site']      = $site;
			$headers['X-Shyaka-Time']      = $time;
			$headers['X-Shyaka-Signature'] = self::signature( $time, $site, $body, self::secret( false ) );
		}
		$url = self::server_url();
		// Supabase reads the action from the body; the query copy only makes server logs easier to read.
		$url = add_query_arg( 'action', rawurlencode( (string) $payload['action'] ), $url );
		return array(
			'url'     => $url,
			'headers' => $headers,
			'body'    => $body,
		);
	}

	/**
	 * Send a request and read the JSON reply.
	 *
	 * @param array $payload JSON body.
	 * @param bool  $signed  Sign it.
	 * @param int   $timeout Seconds.
	 * @return array|WP_Error
	 */
	private static function send( $payload, $signed, $timeout ) {
		$request  = self::build( $payload, $signed );
		$response = wp_remote_post(
			$request['url'],
			array(
				'headers'     => $request['headers'],
				'body'        => $request['body'],
				'timeout'     => $timeout,
				'redirection' => 0,
				'user-agent'  => 'ShyakaForWooCommerce/' . SHYAKA_WC_VERSION . '; ' . self::site(),
			)
		);
		if ( is_wp_error( $response ) ) {
			self::log( $payload['action'], $response->get_error_message() );
			return new WP_Error( 'shyaka_unreachable', __( 'Shyaka couldn’t be reached. Check your internet connection and try again.', 'shyaka-for-woocommerce' ), array( 'status' => 502 ) );
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $data ) ) {
			$data = array();
		}
		if ( $code < 200 || $code >= 300 || ( isset( $data['ok'] ) && false === $data['ok'] ) ) {
			$message = '';
			if ( isset( $data['message'] ) && is_string( $data['message'] ) ) {
				$message = $data['message'];
			} elseif ( isset( $data['error'] ) && is_string( $data['error'] ) ) {
				$message = $data['error'];
			}
			$reason = isset( $data['reason'] ) && is_string( $data['reason'] ) ? $data['reason'] : 'error';
			self::log( $payload['action'], $code . ' ' . $reason . ' ' . $message );
			return new WP_Error(
				'shyaka_refused',
				'' !== $message ? $message : __( 'Something went wrong. Reload the page and try again.', 'shyaka-for-woocommerce' ),
				array(
					'status' => $code ? $code : 500,
					'reason' => $reason,
				)
			);
		}
		return $data;
	}

	/**
	 * Note a failed call in WooCommerce › Status › Logs (source "shyaka"). Never logs secrets or bodies.
	 *
	 * @param string $action  The action.
	 * @param string $message What happened.
	 */
	private static function log( $action, $message ) {
		if ( function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->warning( sprintf( '%s: %s', $action, $message ), array( 'source' => 'shyaka' ) );
		}
	}

	/**
	 * Deactivating the plugin removes the store from Shyaka (signed disconnect), then forgets the secret.
	 */
	public static function on_deactivate() {
		if ( self::has_secret() ) {
			self::call( 'disconnect', array(), 8 );
		}
		self::forget();
		if ( function_exists( 'as_unschedule_all_actions' ) ) {
			as_unschedule_all_actions( '', array(), 'shyaka' );
		}
		wp_unschedule_hook( 'shyaka_wc_product_changed' );
		wp_unschedule_hook( 'shyaka_wc_sync' );
	}
}
