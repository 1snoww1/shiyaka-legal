<?php
/**
 * The optional "Add to Shyaka closet" button on single product pages (off until the shop turns it on in Settings).
 * It only shows for products set to show in Shyaka, under the Add to cart button, in classic and block themes.
 *
 * @package ShyakaForWooCommerce
 */

defined( 'ABSPATH' ) || exit;

/**
 * The storefront button.
 */
final class Shyaka_WC_Storefront {

	const OPTION = 'shyaka_wc_button';

	/**
	 * Printed once per page.
	 *
	 * @var bool
	 */
	private static $printed = false;

	/**
	 * Hooks.
	 */
	public static function init() {
		if ( ! self::enabled() ) {
			return;
		}
		// Block themes: after the Add to cart block. WooCommerce also replays the classic summary hooks inside block
		// templates (at other spots), so the classic hook is only used by classic themes.
		add_filter( 'render_block', array( __CLASS__, 'after_block' ), 10, 2 );
		add_action(
			'after_setup_theme',
			static function () {
				if ( ! function_exists( 'wp_is_block_theme' ) || ! wp_is_block_theme() ) {
					add_action( 'woocommerce_single_product_summary', array( __CLASS__, 'print_button' ), 35 );
				}
			}
		);
	}

	/**
	 * Whether the shop turned the button on.
	 *
	 * @return bool
	 */
	public static function enabled() {
		return 'yes' === get_option( self::OPTION, 'no' );
	}

	/**
	 * The page on shyaka.art that opens the Shyaka app on this product.
	 *
	 * @param int $product_id The product.
	 * @return string
	 */
	public static function add_url( $product_id ) {
		return 'https://shyaka.art/add.html?woo=' . rawurlencode( Shyaka_WC_Client::site() ) . '&product=' . absint( $product_id );
	}

	/**
	 * The button for the product on this page, or '' when it should not show.
	 *
	 * @return string
	 */
	public static function button_html() {
		if ( self::$printed || ! is_product() ) {
			return '';
		}
		$product = wc_get_product( get_queried_object_id() );
		if ( ! $product || ! Shyaka_WC_Products::is_listed( $product->get_id() ) ) {
			return '';
		}
		self::$printed = true;
		$style         = 'display:inline-flex;align-items:center;gap:8px;margin:12px 0;padding:10px 16px;border-radius:999px;background:#0e0e0e;color:#fff;font-size:14px;font-weight:600;line-height:1.2;text-decoration:none';
		$dot           = '<span aria-hidden="true" style="width:10px;height:10px;border-radius:50%;background:#d56bff;display:inline-block"></span>';
		return '<p class="shyaka-add-to-closet"><a href="' . esc_url( self::add_url( $product->get_id() ) ) . '" style="' . esc_attr( $style ) . '" rel="noopener" target="_blank">' . $dot . esc_html__( 'Add to Shyaka closet', 'shyaka-for-woocommerce' ) . '</a></p>';
	}

	/**
	 * Classic themes.
	 */
	public static function print_button() {
		echo self::button_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped parts above.
	}

	/**
	 * Block themes: after the Add to cart block.
	 *
	 * @param string $content Block output.
	 * @param array  $block   The block.
	 * @return string
	 */
	public static function after_block( $content, $block ) {
		$name = isset( $block['blockName'] ) ? $block['blockName'] : '';
		if ( 'woocommerce/add-to-cart-form' === $name || 'woocommerce/add-to-cart-with-options' === $name ) {
			return $content . self::button_html();
		}
		return $content;
	}
}
