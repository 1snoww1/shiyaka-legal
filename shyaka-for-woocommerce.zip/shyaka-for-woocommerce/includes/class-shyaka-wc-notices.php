<?php
/**
 * Tells Shyaka when a product changes, so it can re-read that product. Changes are collected during the request,
 * de-duplicated and handed to WooCommerce's background queue (Action Scheduler), so saving never waits for Shyaka.
 *
 * @package ShyakaForWooCommerce
 */

defined( 'ABSPATH' ) || exit;

/**
 * Signed product_changed notices.
 */
final class Shyaka_WC_Notices {

	const HOOK      = 'shyaka_wc_product_changed';
	const SYNC_HOOK = 'shyaka_wc_sync';
	const GROUP     = 'shyaka';
	// More changes than this in one request (a big bulk edit or import) become one full update instead.
	const MAX_SINGLE = 50;

	/**
	 * Product ids changed in this request.
	 *
	 * @var array<int,bool>
	 */
	private static $changed = array();

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'woocommerce_new_product', array( __CLASS__, 'queue' ) );
		add_action( 'woocommerce_update_product', array( __CLASS__, 'queue' ) );
		add_action( 'woocommerce_new_product_variation', array( __CLASS__, 'queue' ) );
		add_action( 'woocommerce_update_product_variation', array( __CLASS__, 'queue' ) );
		add_action( 'woocommerce_product_set_stock_status', array( __CLASS__, 'queue' ) );
		add_action( 'woocommerce_variation_set_stock_status', array( __CLASS__, 'queue' ) );
		add_action( 'trashed_post', array( __CLASS__, 'queue' ) );
		add_action( 'untrashed_post', array( __CLASS__, 'queue' ) );
		add_action( 'before_delete_post', array( __CLASS__, 'queue' ) );
		add_action( 'added_post_meta', array( __CLASS__, 'meta_changed' ), 10, 3 );
		add_action( 'updated_post_meta', array( __CLASS__, 'meta_changed' ), 10, 3 );
		add_action( 'deleted_post_meta', array( __CLASS__, 'meta_changed' ), 10, 3 );
		add_action( 'shutdown', array( __CLASS__, 'flush' ) );
		add_action( self::HOOK, array( __CLASS__, 'send' ) );
		add_action( self::SYNC_HOOK, array( __CLASS__, 'send_sync' ) );
	}

	/**
	 * The Shyaka setting changed.
	 *
	 * @param int|int[] $meta_id   Meta row id(s).
	 * @param int       $object_id The post.
	 * @param string    $meta_key  The key.
	 */
	public static function meta_changed( $meta_id, $object_id, $meta_key ) {
		if ( Shyaka_WC_Products::META === $meta_key ) {
			self::queue( $object_id );
		}
	}

	/**
	 * Note a changed product (a variation counts as its parent).
	 *
	 * @param mixed $post_id The product or variation.
	 */
	public static function queue( $post_id ) {
		$post_id = is_object( $post_id ) && isset( $post_id->ID ) ? (int) $post_id->ID : absint( $post_id );
		if ( ! $post_id || ! Shyaka_WC_Client::has_secret() ) {
			return;
		}
		$type = get_post_type( $post_id );
		if ( 'product_variation' === $type ) {
			$post_id = (int) wp_get_post_parent_id( $post_id );
			$type    = $post_id ? get_post_type( $post_id ) : '';
		}
		if ( 'product' !== $type || wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}
		if ( 'auto-draft' === get_post_status( $post_id ) ) {
			return;
		}
		self::$changed[ $post_id ] = true;
	}

	/**
	 * At the end of the request, hand the changes to the background queue (one job per product, never twice while one
	 * is waiting).
	 */
	public static function flush() {
		if ( empty( self::$changed ) || ! Shyaka_WC_Client::has_secret() ) {
			return;
		}
		$ids           = array_keys( self::$changed );
		self::$changed = array();
		if ( count( $ids ) > self::MAX_SINGLE ) {
			self::enqueue( self::SYNC_HOOK, array() );
			return;
		}
		foreach ( $ids as $id ) {
			self::enqueue( self::HOOK, array( (int) $id ) );
		}
	}

	/**
	 * One background job, unless the same one is already waiting.
	 *
	 * @param string $hook Hook.
	 * @param array  $args Arguments.
	 */
	private static function enqueue( $hook, $args ) {
		if ( function_exists( 'as_enqueue_async_action' ) ) {
			if ( function_exists( 'as_has_scheduled_action' ) && as_has_scheduled_action( $hook, $args, self::GROUP ) ) {
				return;
			}
			as_enqueue_async_action( $hook, $args, self::GROUP );
			return;
		}
		if ( ! wp_next_scheduled( $hook, $args ) ) {
			wp_schedule_single_event( time(), $hook, $args );
		}
	}

	/**
	 * Background job: tell Shyaka one product changed.
	 *
	 * @param int $id The product.
	 */
	public static function send( $id ) {
		$id = absint( $id );
		if ( $id && Shyaka_WC_Client::has_secret() ) {
			Shyaka_WC_Client::call( 'product_changed', array( 'id' => $id ), 15 );
		}
	}

	/**
	 * Background job: ask Shyaka to read every product again.
	 */
	public static function send_sync() {
		if ( Shyaka_WC_Client::has_secret() ) {
			Shyaka_WC_Client::call( 'sync', array(), 60 );
		}
	}
}
