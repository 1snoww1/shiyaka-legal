<?php
/**
 * Which products show in Shyaka: the shyaka_listed product setting ("yes" or "no"), the "Show in Shyaka" tick on the
 * product page, the Shyaka column and the bulk actions in the product list.
 *
 * @package ShyakaForWooCommerce
 */

defined( 'ABSPATH' ) || exit;

/**
 * The product setting and its controls.
 */
final class Shyaka_WC_Products {

	const META = 'shyaka_listed';

	/**
	 * Registers the setting (also when WooCommerce is off).
	 */
	public static function register_meta_hooks() {
		add_action( 'init', array( __CLASS__, 'register_meta' ) );
		add_filter( 'is_protected_meta', array( __CLASS__, 'protect_meta' ), 10, 2 );
	}

	/**
	 * Adds the controls.
	 */
	public static function init() {
		add_action( 'woocommerce_product_options_general_product_data', array( __CLASS__, 'product_field' ) );
		add_action( 'woocommerce_admin_process_product_object', array( __CLASS__, 'save_product_field' ) );
		add_filter( 'manage_edit-product_columns', array( __CLASS__, 'add_column' ), 20 );
		add_action( 'manage_product_posts_custom_column', array( __CLASS__, 'render_column' ), 10, 2 );
		add_filter( 'bulk_actions-edit-product', array( __CLASS__, 'bulk_actions' ) );
		add_filter( 'handle_bulk_actions-edit-product', array( __CLASS__, 'handle_bulk' ), 10, 3 );
		add_action( 'admin_notices', array( __CLASS__, 'bulk_notice' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'column_style' ) );
	}

	/**
	 * The setting itself, readable and writable through the REST API by people who can edit the product.
	 */
	public static function register_meta() {
		register_post_meta(
			'product',
			self::META,
			array(
				'type'              => 'string',
				'description'       => __( 'Whether the product shows in Shyaka: yes or no.', 'shyaka-for-woocommerce' ),
				'single'            => true,
				'default'           => 'no',
				'show_in_rest'      => array(
					'schema' => array(
						'type' => 'string',
						'enum' => array( 'yes', 'no' ),
					),
				),
				'auth_callback'     => static function ( $allowed, $meta_key, $post_id ) {
					return current_user_can( 'edit_post', $post_id );
				},
				'sanitize_callback' => array( __CLASS__, 'sanitize' ),
			)
		);
	}

	/**
	 * Keeps the setting out of WordPress's Custom Fields box (it has its own tick).
	 *
	 * @param bool   $is_protected Whether the key is protected.
	 * @param string $meta_key  The key.
	 * @return bool
	 */
	public static function protect_meta( $is_protected, $meta_key ) {
		return self::META === $meta_key ? true : $is_protected;
	}

	/**
	 * Only "yes" or "no".
	 *
	 * @param mixed $value The value.
	 * @return string
	 */
	public static function sanitize( $value ) {
		return 'yes' === $value || true === $value || '1' === $value || 1 === $value ? 'yes' : 'no';
	}

	/**
	 * Whether a product is set to show in Shyaka.
	 *
	 * @param int $product_id The product.
	 * @return bool
	 */
	public static function is_listed( $product_id ) {
		return 'yes' === get_post_meta( $product_id, self::META, true );
	}

	/**
	 * Turn a product on or off. Saving fires WooCommerce's own update, which sends the change to Shyaka.
	 *
	 * @param WC_Product $product The product.
	 * @param bool       $listed  Show in Shyaka.
	 */
	public static function set_listed( $product, $listed ) {
		$product->update_meta_data( self::META, $listed ? 'yes' : 'no' );
		$product->save();
	}

	/**
	 * How many products are set to show in Shyaka, and how many products the store has (not counting drafts in the bin).
	 *
	 * @return array{listed:int,total:int}
	 */
	public static function counts() {
		$base   = array(
			'post_type'              => 'product',
			'post_status'            => array( 'publish', 'private', 'draft', 'pending', 'future' ),
			'posts_per_page'         => 1,
			'fields'                 => 'ids',
			'no_found_rows'          => false,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
		);
		$all    = new WP_Query( $base );
		$listed = new WP_Query(
			array_merge(
				$base,
				array(
					'meta_key'   => self::META, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
					'meta_value' => 'yes', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				)
			)
		);
		return array(
			'listed' => (int) $listed->found_posts,
			'total'  => (int) $all->found_posts,
		);
	}

	/**
	 * The "Show in Shyaka" tick in the product data panel (General tab).
	 */
	public static function product_field() {
		global $product_object;
		$value = $product_object instanceof WC_Product ? $product_object->get_meta( self::META ) : '';
		echo '<div class="options_group show_if_simple show_if_variable">';
		woocommerce_wp_checkbox(
			array(
				'id'          => self::META,
				'value'       => 'yes' === $value ? 'yes' : 'no',
				'cbvalue'     => 'yes',
				'label'       => __( 'Show in Shyaka', 'shyaka-for-woocommerce' ),
				'description' => __( 'Shoppers can find this product in the Shyaka iPhone app. Only published, visible products that are in stock show.', 'shyaka-for-woocommerce' ),
			)
		);
		echo '</div>';
	}

	/**
	 * Saves the tick. WooCommerce has already checked the product form's nonce and the user's rights.
	 *
	 * @param WC_Product $product The product being saved.
	 */
	public static function save_product_field( $product ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified by WooCommerce before this action runs.
		$listed = isset( $_POST[ self::META ] ) && 'yes' === sanitize_text_field( wp_unslash( $_POST[ self::META ] ) );
		$product->update_meta_data( self::META, $listed ? 'yes' : 'no' );
	}

	/**
	 * The Shyaka column, before the date.
	 *
	 * @param array $columns Columns.
	 * @return array
	 */
	public static function add_column( $columns ) {
		$out = array();
		foreach ( $columns as $key => $label ) {
			if ( 'date' === $key ) {
				$out['shyaka'] = __( 'Shyaka', 'shyaka-for-woocommerce' );
			}
			$out[ $key ] = $label;
		}
		if ( ! isset( $out['shyaka'] ) ) {
			$out['shyaka'] = __( 'Shyaka', 'shyaka-for-woocommerce' );
		}
		return $out;
	}

	/**
	 * One cell of the Shyaka column.
	 *
	 * @param string $column  Column key.
	 * @param int    $post_id The product.
	 */
	public static function render_column( $column, $post_id ) {
		if ( 'shyaka' !== $column ) {
			return;
		}
		if ( self::is_listed( $post_id ) ) {
			echo '<span class="shyaka-col shyaka-col--on">' . esc_html__( 'In Shyaka', 'shyaka-for-woocommerce' ) . '</span>';
		} else {
			echo '<span class="shyaka-col" aria-label="' . esc_attr__( 'Not in Shyaka', 'shyaka-for-woocommerce' ) . '">&ndash;</span>';
		}
	}

	/**
	 * A little room for the column.
	 */
	public static function column_style() {
		$screen = get_current_screen();
		if ( ! $screen || 'edit-product' !== $screen->id ) {
			return;
		}
		wp_register_style( 'shyaka-wc-list', false, array(), SHYAKA_WC_VERSION );
		wp_enqueue_style( 'shyaka-wc-list' );
		wp_add_inline_style( 'shyaka-wc-list', '.column-shyaka{width:90px}.shyaka-col--on{display:inline-block;padding:1px 8px;border-radius:10px;background:#0e0e0e;color:#fff;font-size:12px;line-height:18px;white-space:nowrap}' );
	}

	/**
	 * Show in Shyaka / Hide from Shyaka in the Bulk actions menu.
	 *
	 * @param array $actions Bulk actions.
	 * @return array
	 */
	public static function bulk_actions( $actions ) {
		if ( current_user_can( 'edit_products' ) ) { // phpcs:ignore WordPress.WP.Capabilities.Unknown -- WooCommerce's capability.
			$actions['shyaka_show'] = __( 'Show in Shyaka', 'shyaka-for-woocommerce' );
			$actions['shyaka_hide'] = __( 'Hide from Shyaka', 'shyaka-for-woocommerce' );
		}
		return $actions;
	}

	/**
	 * Applies a bulk action. WordPress has already checked the list's nonce.
	 *
	 * @param string $redirect Where to go next.
	 * @param string $action   The chosen action.
	 * @param int[]  $ids      The ticked products.
	 * @return string
	 */
	public static function handle_bulk( $redirect, $action, $ids ) {
		if ( 'shyaka_show' !== $action && 'shyaka_hide' !== $action ) {
			return $redirect;
		}
		$changed = 0;
		foreach ( array_map( 'absint', (array) $ids ) as $id ) {
			if ( ! current_user_can( 'edit_post', $id ) ) {
				continue;
			}
			$product = wc_get_product( $id );
			if ( ! $product || $product->is_type( 'variation' ) ) {
				continue;
			}
			self::set_listed( $product, 'shyaka_show' === $action );
			++$changed;
		}
		return add_query_arg(
			array(
				'shyaka_bulk'    => $changed,
				'shyaka_bulk_on' => 'shyaka_show' === $action ? 1 : 0,
			),
			remove_query_arg( array( 'shyaka_bulk', 'shyaka_bulk_on' ), $redirect )
		);
	}

	/**
	 * Says what a bulk action did.
	 */
	public static function bulk_notice() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- display only.
		if ( ! isset( $_GET['shyaka_bulk'], $_GET['post_type'] ) || 'product' !== sanitize_key( wp_unslash( $_GET['post_type'] ) ) ) {
			return;
		}
		$count = absint( $_GET['shyaka_bulk'] );
		$on    = ! empty( $_GET['shyaka_bulk_on'] );
		// phpcs:enable
		$message = $on
			/* translators: %d: number of products. */
			? sprintf( _n( '%d product set to show in Shyaka.', '%d products set to show in Shyaka.', $count, 'shyaka-for-woocommerce' ), $count )
			/* translators: %d: number of products. */
			: sprintf( _n( '%d product hidden from Shyaka.', '%d products hidden from Shyaka.', $count, 'shyaka-for-woocommerce' ), $count );
		echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $message ) . '</p></div>';
	}

	/**
	 * The link that opens the store's checkout with this product in the cart (what Buy in Shyaka does), or '' when the
	 * product can't be bought now.
	 *
	 * @param WC_Product $product The product.
	 * @return string
	 */
	public static function buy_link( $product ) {
		$id = 0;
		if ( $product->is_type( 'variable' ) ) {
			foreach ( $product->get_children() as $child_id ) {
				$child = wc_get_product( $child_id );
				if ( $child && $child->is_purchasable() && $child->is_in_stock() ) {
					$id = $child_id;
					break;
				}
			}
		} elseif ( $product->is_type( 'simple' ) && $product->is_purchasable() && $product->is_in_stock() ) {
			$id = $product->get_id();
		}
		return $id ? add_query_arg( 'add-to-cart', $id, wc_get_checkout_url() ) : '';
	}
}
