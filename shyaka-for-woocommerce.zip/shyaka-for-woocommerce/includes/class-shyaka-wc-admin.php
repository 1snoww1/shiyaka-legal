<?php
/**
 * WooCommerce › Shyaka: Home, Products, Results and Settings. The page's script talks only to WordPress (admin-ajax
 * with a nonce and the manage_woocommerce right); this class signs and forwards to Shyaka.
 *
 * @package ShyakaForWooCommerce
 */

defined( 'ABSPATH' ) || exit;

/**
 * The admin page.
 */
final class Shyaka_WC_Admin {

	const SLUG  = 'shyaka';
	const NONCE = 'shyaka_admin';
	const CAP   = 'manage_woocommerce';

	/**
	 * Server actions the page may ask for, and nothing else.
	 */
	const SERVER_OPS = array( 'status', 'products', 'sync', 'stats', 'link', 'plan', 'subscribe', 'cancelplan', 'unlink', 'disconnect' );

	/**
	 * The page's hook suffix.
	 *
	 * @var string
	 */
	private static $hook = '';

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 60 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'wp_ajax_shyaka_api', array( __CLASS__, 'ajax_server' ) );
		add_action( 'wp_ajax_shyaka_local', array( __CLASS__, 'ajax_local' ) );
		add_action( 'admin_post_shyaka_connect', array( __CLASS__, 'connect' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( SHYAKA_WC_FILE ), array( __CLASS__, 'action_links' ) );
	}

	/**
	 * WooCommerce › Shyaka.
	 */
	public static function menu() {
		self::$hook = (string) add_submenu_page(
			'woocommerce',
			__( 'Shyaka', 'shyaka-for-woocommerce' ),
			__( 'Shyaka', 'shyaka-for-woocommerce' ),
			self::CAP,
			self::SLUG,
			array( __CLASS__, 'render' )
		);
	}

	/**
	 * "Open Shyaka" on the Plugins screen.
	 *
	 * @param array $links Links.
	 * @return array
	 */
	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( self::url() ) . '">' . esc_html__( 'Open Shyaka', 'shyaka-for-woocommerce' ) . '</a>' );
		return $links;
	}

	/**
	 * A page address.
	 *
	 * @param string $tab home, products, results or settings.
	 * @return string
	 */
	public static function url( $tab = 'home' ) {
		$args = array( 'page' => self::SLUG );
		if ( 'home' !== $tab ) {
			$args['tab'] = $tab;
		}
		return add_query_arg( $args, admin_url( 'admin.php' ) );
	}

	/**
	 * The open tab.
	 *
	 * @return string
	 */
	private static function tab() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- choosing a tab changes nothing.
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'home';
		if ( 'help' === $tab ) {
			$tab = 'settings';
		}
		return in_array( $tab, array( 'home', 'products', 'results', 'settings' ), true ) ? $tab : 'home';
	}

	/**
	 * Scripts and styles, on this page only.
	 *
	 * @param string $hook The page.
	 */
	public static function assets( $hook ) {
		if ( '' === self::$hook || self::$hook !== $hook ) {
			return;
		}
		wp_enqueue_style( 'shyaka-wc-admin', SHYAKA_WC_URL . 'assets/css/admin.css', array(), SHYAKA_WC_VERSION );
		wp_register_script( 'shyaka-wc-qrcode', SHYAKA_WC_URL . 'assets/vendor/qrcode.js', array(), '2009', true );
		wp_enqueue_script( 'shyaka-wc-admin', SHYAKA_WC_URL . 'assets/js/shyaka.js', array( 'wp-i18n', 'shyaka-wc-qrcode' ), SHYAKA_WC_VERSION, true );
		wp_set_script_translations( 'shyaka-wc-admin', 'shyaka-for-woocommerce' );

		$user_id = get_current_user_id();
		$error   = get_transient( 'shyaka_wc_connect_error_' . $user_id );
		if ( false !== $error ) {
			delete_transient( 'shyaka_wc_connect_error_' . $user_id );
		}
		// WooCommerce's approval screen sends the shop back here with success=1 or success=0.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display only.
		$returned = isset( $_GET['success'], $_GET['user_id'] ) ? ( '1' === sanitize_text_field( wp_unslash( $_GET['success'] ) ) ? 'approved' : 'declined' ) : '';
		$site     = Shyaka_WC_Client::site();
		$counts   = Shyaka_WC_Products::counts();

		wp_localize_script(
			'shyaka-wc-admin',
			'ShyakaWC',
			array(
				'ajaxUrl'      => admin_url( 'admin-ajax.php' ),
				'nonce'        => wp_create_nonce( self::NONCE ),
				'connectUrl'   => admin_url( 'admin-post.php' ),
				'connectNonce' => wp_create_nonce( 'shyaka_connect' ),
				'tab'          => self::tab(),
				'urls'         => array(
					'home'       => self::url(),
					'products'   => self::url( 'products' ),
					'results'    => self::url( 'results' ),
					'settings'   => self::url( 'settings' ),
					'wcProducts' => admin_url( 'edit.php?post_type=product' ),
					'permalinks' => admin_url( 'options-permalink.php' ),
					'plugins'    => admin_url( 'plugins.php' ),
					'support'    => 'https://shyaka.art/support.html',
					'privacy'    => 'https://shyaka.art/privacy.html',
					'terms'      => 'https://shyaka.art/terms.html',
					'app'        => 'https://shyaka.art/',
				),
				'email'        => 'support@shyaka.art',
				'site'         => $site,
				'shopName'     => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
				'connected'    => Shyaka_WC_Client::has_secret(),
				'listed'       => $counts['listed'],
				'total'        => $counts['total'],
				'button'       => Shyaka_WC_Storefront::enabled(),
				'permalinks'   => '' !== (string) get_option( 'permalink_structure' ),
				'https'        => 0 === strpos( $site, 'https://' ),
				'returned'     => $returned,
				'connectError' => is_string( $error ) ? $error : '',
			)
		);
	}

	/**
	 * The page shell; the script fills it.
	 */
	public static function render() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'You don’t have permission to manage Shyaka.', 'shyaka-for-woocommerce' ) );
		}
		$tab  = self::tab();
		$tabs = array(
			'home'     => __( 'Home', 'shyaka-for-woocommerce' ),
			'products' => __( 'Products', 'shyaka-for-woocommerce' ),
			'results'  => __( 'Results', 'shyaka-for-woocommerce' ),
			'settings' => __( 'Settings', 'shyaka-for-woocommerce' ),
		);
		?>
		<div class="wrap shyaka-wrap">
			<h1 class="screen-reader-text"><?php esc_html_e( 'Shyaka', 'shyaka-for-woocommerce' ); ?></h1>
			<div class="shyaka-brand">
				<img class="shyaka-wordmark" src="<?php echo esc_url( SHYAKA_WC_URL . 'assets/img/wordmark.svg' ); ?>" alt="<?php esc_attr_e( 'Shyaka', 'shyaka-for-woocommerce' ); ?>" width="101" height="22">
				<div class="shyaka-shop">
					<strong><?php echo esc_html( wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) ); ?></strong>
					<span><?php echo esc_html( Shyaka_WC_Client::site() ); ?></span>
				</div>
				<span class="shyaka-badge" id="shyaka-standing"><?php esc_html_e( 'Checking…', 'shyaka-for-woocommerce' ); ?></span>
			</div>
			<hr class="wp-header-end">
			<nav class="nav-tab-wrapper shyaka-tabs" aria-label="<?php esc_attr_e( 'Shyaka pages', 'shyaka-for-woocommerce' ); ?>">
				<?php foreach ( $tabs as $key => $label ) : ?>
					<a href="<?php echo esc_url( self::url( $key ) ); ?>" class="nav-tab<?php echo $key === $tab ? ' nav-tab-active' : ''; ?>"<?php echo $key === $tab ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $label ); ?></a>
				<?php endforeach; ?>
			</nav>
			<div id="shyaka-messages" aria-live="polite"></div>
			<div id="shyaka-app" data-tab="<?php echo esc_attr( $tab ); ?>">
				<p class="shyaka-loading"><span class="spinner is-active"></span><?php esc_html_e( 'Checking your store…', 'shyaka-for-woocommerce' ); ?></p>
			</div>
			<noscript><p><?php esc_html_e( 'Shyaka needs JavaScript to show your store.', 'shyaka-for-woocommerce' ); ?></p></noscript>
			<p class="shyaka-footer">
				<?php esc_html_e( 'Need help?', 'shyaka-for-woocommerce' ); ?>
				<a href="https://shyaka.art/support.html" target="_blank" rel="noopener"><?php esc_html_e( 'Help and support', 'shyaka-for-woocommerce' ); ?></a>
				<?php esc_html_e( 'or', 'shyaka-for-woocommerce' ); ?>
				<a href="mailto:support@shyaka.art">support@shyaka.art</a>
			</p>
		</div>
		<?php
	}

	/**
	 * Checks the nonce and the user's rights for an AJAX call.
	 */
	private static function guard() {
		if ( ! check_ajax_referer( self::NONCE, 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => __( 'This page has expired. Reload it and try again.', 'shyaka-for-woocommerce' ) ), 403 );
		}
		if ( ! current_user_can( self::CAP ) ) {
			wp_send_json_error( array( 'message' => __( 'You don’t have permission to manage Shyaka.', 'shyaka-for-woocommerce' ) ), 403 );
		}
	}

	/**
	 * A field from the AJAX request.
	 *
	 * @param string $key Field.
	 * @return string
	 */
	private static function field( $key ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- guard() checks the nonce first.
		return isset( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : '';
	}

	/**
	 * Forwards one allowed action to Shyaka, signed.
	 */
	public static function ajax_server() {
		self::guard();
		$op = self::field( 'op' );
		if ( ! in_array( $op, self::SERVER_OPS, true ) ) {
			wp_send_json_error( array( 'message' => __( 'Unknown request.', 'shyaka-for-woocommerce' ) ), 400 );
		}
		$extra = array();
		switch ( $op ) {
			case 'status':
				if ( ! Shyaka_WC_Client::has_secret() ) {
					wp_send_json_success( array( 'state' => 'none' ) );
				}
				break;
			case 'products':
				// Shyaka's own copy of the products: pages count from 0, 50 a page.
				$extra['page']   = min( 1000, absint( self::field( 'page' ) ) );
				$filter          = self::field( 'filter' );
				$extra['filter'] = in_array( $filter, array( 'all', 'listed', 'hidden', 'shown' ), true ) ? $filter : 'all';
				$extra['search'] = mb_substr( self::field( 'search' ), 0, 80 );
				break;
			case 'stats':
				$extra['days'] = '30' === self::field( 'days' ) ? 30 : 7;
				break;
			case 'subscribe':
				$plan = self::field( 'plan' );
				if ( ! in_array( $plan, array( 'starter', 'growth', 'pro' ), true ) ) {
					wp_send_json_error( array( 'message' => __( 'Choose Starter, Growth or Pro.', 'shyaka-for-woocommerce' ) ), 400 );
				}
				$extra['plan'] = $plan;
				break;
		}
		$reply = Shyaka_WC_Client::call( $op, $extra, 'sync' === $op ? 60 : 20 );
		if ( is_wp_error( $reply ) ) {
			$data   = (array) $reply->get_error_data();
			$status = isset( $data['status'] ) ? (int) $data['status'] : 500;
			// A store Shyaka doesn't know (never finished connecting, or removed) simply shows the Connect step again.
			if ( 'status' === $op && in_array( $status, array( 401, 403, 404 ), true ) ) {
				wp_send_json_success(
					array(
						'state' => 'none',
						'note'  => $reply->get_error_message(),
					)
				);
			}
			wp_send_json_error(
				array(
					'message' => $reply->get_error_message(),
					'reason'  => isset( $data['reason'] ) ? $data['reason'] : 'error',
				),
				$status >= 400 && $status < 600 ? $status : 500
			);
		}
		if ( 'disconnect' === $op ) {
			Shyaka_WC_Client::forget();
		}
		// Shyaka keeps the storefront button setting too; its copy wins, so a change made elsewhere shows here.
		if ( 'status' === $op && isset( $reply['button'] ) && is_bool( $reply['button'] ) && 'none' !== ( isset( $reply['state'] ) ? $reply['state'] : 'none' ) ) {
			update_option( Shyaka_WC_Storefront::OPTION, $reply['button'] ? 'yes' : 'no' );
		}
		wp_send_json_success( $reply );
	}

	/**
	 * Things the page does in WordPress itself: list products, turn one on or off, the storefront button setting.
	 */
	public static function ajax_local() {
		self::guard();
		$op = self::field( 'op' );
		if ( 'products' === $op ) {
			wp_send_json_success( self::local_products() );
		}
		if ( 'set_listed' === $op ) {
			$id      = absint( self::field( 'id' ) );
			$product = $id ? wc_get_product( $id ) : null;
			if ( ! $product || $product->is_type( 'variation' ) || ! current_user_can( 'edit_post', $id ) ) {
				wp_send_json_error( array( 'message' => __( 'That product couldn’t be changed.', 'shyaka-for-woocommerce' ) ), 400 );
			}
			$listed = self::field( 'listed' );
			Shyaka_WC_Products::set_listed( $product, '1' === $listed );
			wp_send_json_success(
				array(
					'listed' => Shyaka_WC_Products::is_listed( $id ),
					'counts' => Shyaka_WC_Products::counts(),
				)
			);
		}
		if ( 'button' === $op ) {
			$on = '1' === self::field( 'on' );
			// Tell Shyaka first (it keeps the setting and reports it in status); a store not connected yet keeps it here only.
			if ( Shyaka_WC_Client::has_secret() ) {
				$reply = Shyaka_WC_Client::call( 'settings', array( 'button' => $on ) );
				if ( is_wp_error( $reply ) ) {
					$data = (array) $reply->get_error_data();
					if ( ! in_array( isset( $data['status'] ) ? (int) $data['status'] : 0, array( 401, 404 ), true ) ) {
						wp_send_json_error( array( 'message' => $reply->get_error_message() ), 502 );
					}
				}
			}
			update_option( Shyaka_WC_Storefront::OPTION, $on ? 'yes' : 'no' );
			wp_send_json_success( array( 'button' => Shyaka_WC_Storefront::enabled() ) );
		}
		wp_send_json_error( array( 'message' => __( 'Unknown request.', 'shyaka-for-woocommerce' ) ), 400 );
	}

	/**
	 * One page of the store's products for the Products tab.
	 *
	 * @return array
	 */
	private static function local_products() {
		$per_page = 20;
		$page     = max( 1, absint( self::field( 'page' ) ) );
		$filter   = self::field( 'filter' );
		$search   = self::field( 'search' );
		$args     = array(
			'post_type'      => 'product',
			'post_status'    => array( 'publish', 'private', 'draft', 'pending', 'future' ),
			'posts_per_page' => $per_page,
			'paged'          => $page,
			'orderby'        => 'title',
			'order'          => 'ASC',
		);
		if ( '' !== $search ) {
			$args['s'] = $search;
		}
		if ( 'in' === $filter ) {
			$args['meta_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
				array(
					'key'   => Shyaka_WC_Products::META,
					'value' => 'yes',
				),
			);
		} elseif ( 'out' === $filter ) {
			$args['meta_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
				'relation' => 'OR',
				array(
					'key'     => Shyaka_WC_Products::META,
					'compare' => 'NOT EXISTS',
				),
				array(
					'key'     => Shyaka_WC_Products::META,
					'value'   => 'yes',
					'compare' => '!=',
				),
			);
		}
		$query = new WP_Query( $args );
		$items = array();
		foreach ( $query->posts as $post ) {
			$product = wc_get_product( $post );
			if ( ! $product ) {
				continue;
			}
			$image_id = $product->get_image_id();
			$items[]  = array(
				'id'      => $product->get_id(),
				'title'   => wp_specialchars_decode( $product->get_name(), ENT_QUOTES ),
				'image'   => $image_id ? (string) wp_get_attachment_image_url( (int) $image_id, 'thumbnail' ) : '',
				'status'  => $product->get_status(),
				'visible' => in_array( $product->get_catalog_visibility(), array( 'visible', 'catalog' ), true ),
				'inStock' => $product->is_in_stock(),
				'type'    => $product->get_type(),
				'price'   => self::plain_price( $product ),
				'listed'  => Shyaka_WC_Products::is_listed( $product->get_id() ),
				'edit'    => (string) get_edit_post_link( $product->get_id(), 'raw' ),
				'buy'     => 'publish' === $product->get_status() ? Shyaka_WC_Products::buy_link( $product ) : '',
			);
		}
		return array(
			'items' => $items,
			'page'  => $page,
			'pages' => (int) $query->max_num_pages,
			'total' => (int) $query->found_posts,
		);
	}

	/**
	 * The product's price as plain text (WooCommerce's price HTML without its screen-reader copy).
	 *
	 * @param WC_Product $product The product.
	 * @return string
	 */
	private static function plain_price( $product ) {
		$html = (string) $product->get_price_html();
		$html = preg_replace( '#<span class="screen-reader-text">.*?</span>#s', '', $html );
		$text = html_entity_decode( wp_strip_all_tags( (string) $html ), ENT_QUOTES, 'UTF-8' );
		return trim( preg_replace( '/\s+/u', ' ', $text ) );
	}

	/**
	 * Connect: tell Shyaka a store is starting to connect (only the secret's hash), then open WooCommerce's own approval
	 * screen at the address Shyaka returns.
	 */
	public static function connect() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'You don’t have permission to manage Shyaka.', 'shyaka-for-woocommerce' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'shyaka_connect' );
		$back = self::url();
		$fail = static function ( $message ) use ( $back ) {
			set_transient( 'shyaka_wc_connect_error_' . get_current_user_id(), $message, 120 );
			wp_safe_redirect( $back );
			exit;
		};
		if ( '' === (string) get_option( 'permalink_structure' ) ) {
			$fail( __( 'WooCommerce’s approval screen needs pretty permalinks. In Settings › Permalinks choose any option except Plain, save, then connect again.', 'shyaka-for-woocommerce' ) );
		}
		$reply = Shyaka_WC_Client::connect_begin();
		if ( is_wp_error( $reply ) ) {
			$fail( $reply->get_error_message() );
		}
		$url    = isset( $reply['authorize_url'] ) && is_string( $reply['authorize_url'] ) ? $reply['authorize_url'] : '';
		$expect = Shyaka_WC_Client::site() . '/wc-auth/v1/authorize?';
		// Only ever this store's own approval screen.
		if ( 0 !== strpos( strtolower( $url ), $expect ) ) {
			$fail( __( 'Shyaka sent an unexpected address. Try again in a minute.', 'shyaka-for-woocommerce' ) );
		}
		wp_safe_redirect( $url );
		exit;
	}
}
