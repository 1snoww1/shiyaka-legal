=== Shyaka for WooCommerce ===
Contributors: thesnow
Tags: woocommerce, fashion, marketplace, wardrobe, iphone
Requires at least: 6.3
Tested up to: 7.1
Requires PHP: 7.4
Requires Plugins: woocommerce
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Show your clothing, shoes and accessories in Shyaka, the iPhone wardrobe app. Shoppers style your pieces with what they own and buy on your store.

== Description ==

Shyaka is an iPhone app where people keep their closet, plan outfits and find new pieces. With this plugin, the products you choose appear in Shyaka's Market and on your own shop page there. Shoppers can save a product, add its photo to their closet to style it with what they already own, and tap Buy to go to your own checkout with the piece already in the cart. Payment, delivery and returns all happen in your store, as they do today.

**What you get in WooCommerce › Shyaka**

* **Home:** the setup steps (connect your store, link the Shyaka iPhone app, choose products), then the last 7 days of views, saves, closet adds and Buy taps, your plan and your products.
* **Products:** a switch for each product, with filters and search, and an Update now button.
* **Results:** the same four numbers for the last 7 or 30 days, product by product.
* **Settings:** your plan, your Shyaka account and linking code, the optional "Add to Shyaka closet" button for your product pages, help, and disconnecting.

**Choosing products**

* A "Show in Shyaka" tick on each product's page (Product data › General).
* A Shyaka column and two bulk actions, "Show in Shyaka" and "Hide from Shyaka", in the Products list.
* Switches on the Shyaka page.

Only published products that are visible in your shop and in stock appear in Shyaka. When you change a product, the plugin tells Shyaka in the background, so Shyaka shows the change within a minute and saving is never slowed down.

**Plans**

Founding shops are free until 30 April 2027. After that, Starter, Growth and Pro plans are paid by invoice from Shyaka. Shyaka takes no commission on your sales.

**Who can join**

Clothing, shoe and accessory shops selling to shoppers in Egypt. Linking needs the Shyaka iPhone app, and Shyaka checks each business before its products show.

== External services ==

This plugin connects your store to **Shyaka**, an external service run by Shyaka (https://shyaka.art/). It does not work without it.

* **Shyaka's server** (`https://yxxryttfcwgirxhhrdjc.supabase.co/functions/v1/woocommerce`, hosted on Supabase) receives:
  * When you click **Connect to Shyaka**: your store's address, your store's name, the site administrator email address, your checkout address, the WordPress, WooCommerce and plugin versions, and a one-way hash of a secret the plugin makes for your store. The secret itself never leaves your site.
  * When you change a product: the product's ID, so Shyaka can read that product again.
  * When you open the Shyaka page or use its buttons: the request you made (for example your plan, your numbers or a linking code).
  * When you deactivate or delete the plugin: a request to remove your store from Shyaka.
  Every request after Connect is signed, so Shyaka knows it came from your store.
* **WooCommerce's approval screen** on your own site then asks you to give Shyaka **read-only** access to your store. With it, Shyaka reads your products: titles, descriptions, prices, photos, options, stock, and which products you chose for Shyaka. WooCommerce's screen lists everything read-only access would allow, which includes orders, coupons and customers; Shyaka only reads products and never reads your orders, customers or payments. It never sees your WordPress password.
* The optional **Add to Shyaka closet** button links shoppers to `https://shyaka.art/add.html` with your store's address and the product's ID, which opens the Shyaka app.

Shyaka's terms: https://shyaka.art/terms.html
Shyaka's privacy policy: https://shyaka.art/privacy.html

== Privacy ==

The plugin adds no cookies and no tracking to your storefront. It stores, in your WordPress database: a secret for your store (never sent anywhere, not loaded on every page), whether the storefront button is on, and a "Show in Shyaka" setting on each product. Deleting the plugin removes all three and asks Shyaka to delete your store's connection and products.

What reaches Shyaka is listed under External services above. Shoppers who use Shyaka are covered by Shyaka's own privacy policy: https://shyaka.art/privacy.html

== Installation ==

1. Install and activate WooCommerce.
2. Upload the plugin in Plugins › Add New › Upload Plugin, then activate it.
3. Make sure Settings › Permalinks is not set to Plain (WooCommerce's approval screen needs this) and that your store uses https.
4. Open WooCommerce › Shyaka and click **Connect to Shyaka**. Approve the read-only access WooCommerce asks for.
5. Click **Show my linking code** and scan it with your iPhone camera (or tap **Open in Shyaka** on the iPhone).
6. Choose your products.

== Frequently Asked Questions ==

= Does Shyaka take payments or handle orders? =

No. Buy in Shyaka opens your own checkout with the piece in the cart. Payment, delivery and returns happen in your store. Shyaka takes no commission.

= What can Shyaka see in my store? =

Your products only, with WooCommerce's read-only approval. Not your orders, customers or payments.

= Which products show in Shyaka? =

Only the ones you turn on, and only while they are published, visible in your shop and in stock.

= Do I need an iPhone? =

Linking your store to a Shyaka business is done once in the Shyaka iPhone app. After that you manage everything here.

= How do I stop showing my products? =

In WooCommerce › Shyaka › Settings choose **Disconnect from Shyaka** (keeps the connection so you can link again) or **Remove the connection** (deletes everything Shyaka holds for your store). Deactivating or deleting the plugin also removes your store from Shyaka.

= Does it work with block themes and the new product editor? =

The storefront button works with classic and block themes. The "Show in Shyaka" tick is in the classic product editor; the Products list and the Shyaka page work with either.

== Screenshots ==

1. Home: setup steps, the last 7 days, plan and products.
2. Products: a switch for each product.
3. Settings: plan, linking code and the storefront button.

== Changelog ==

= 1.0.0 =
* First release.

== Upgrade Notice ==

= 1.0.0 =
First release.

== Credits ==

QR codes are drawn with qrcode-generator by Kazuhiko Arase (MIT licence), included in assets/vendor.
