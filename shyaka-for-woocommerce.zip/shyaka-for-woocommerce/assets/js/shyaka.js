/**
 * WooCommerce › Shyaka. The same four pages as Shyaka's page in the Shopify admin: Home (setup steps first, then the
 * week's numbers with the plan and products on the side), Products, Results and Settings.
 *
 * Talks only to WordPress (admin-ajax with a nonce); WordPress signs and forwards to Shyaka. Text is set with
 * textContent only.
 */
/* global ShyakaWC, wp, qrcode */
( function () {
	'use strict';

	var cfg = window.ShyakaWC || {};
	var __ = wp.i18n.__;
	var _n = wp.i18n._n;
	var sprintf = wp.i18n.sprintf;
	var app = document.getElementById( 'shyaka-app' );
	var IPHONE = /\b(iPhone|iPod)\b/.test( navigator.userAgent || '' );
	var LOCALE = document.documentElement.lang || undefined;

	/** Build an element. Attributes go through setAttribute; children are nodes or plain text. */
	function h( tag, attrs, children ) {
		var el = document.createElement( tag );
		Object.keys( attrs || {} ).forEach( function ( k ) {
			var v = attrs[ k ];
			if ( v === false || v === null || v === undefined ) {
				return;
			}
			if ( k === 'on' ) {
				Object.keys( v ).forEach( function ( e ) {
					el.addEventListener( e, v[ e ] );
				} );
			} else if ( k === 'className' ) {
				el.className = v;
			} else {
				el.setAttribute( k, v === true ? '' : String( v ) );
			}
		} );
		[].concat( children === undefined ? [] : children ).forEach( function ( c ) {
			if ( c === null || c === undefined || c === false ) {
				return;
			}
			el.appendChild( typeof c === 'string' || typeof c === 'number' ? document.createTextNode( String( c ) ) : c );
		} );
		return el;
	}
	function para( t ) {
		return h( 'p', {}, t );
	}
	function muted( t ) {
		return h( 'p', { className: 'shyaka-muted' }, t );
	}
	function badge( tone, t ) {
		return h( 'span', { className: 'shyaka-badge shyaka-badge--' + tone }, t );
	}
	function extLink( href, t ) {
		return h( 'a', { href: href, target: '_blank', rel: 'noopener' }, t );
	}
	function row( children ) {
		return h( 'div', { className: 'shyaka-row' }, children );
	}
	function button( label, primary, attrs ) {
		return h( 'button', Object.assign( { type: 'button', className: 'button' + ( primary ? ' button-primary' : '' ) }, attrs || {} ), label );
	}
	function linkButton( href, label, primary, external ) {
		return h( 'a', { href: href, className: 'button' + ( primary ? ' button-primary' : '' ), target: external ? '_blank' : null, rel: external ? 'noopener' : null }, label );
	}
	function card( heading, children, attrs ) {
		return h( 'section', Object.assign( { className: 'shyaka-card' }, attrs || {} ), [ heading ? h( 'h2', {}, heading ) : null ].concat( children ) );
	}
	function spinner() {
		return h( 'p', { className: 'shyaka-loading' }, [ h( 'span', { className: 'spinner is-active' } ), __( 'Loading…', 'shyaka-for-woocommerce' ) ] );
	}
	function fill( holder, nodes ) {
		holder.textContent = '';
		[].concat( nodes ).forEach( function ( n ) {
			if ( n ) {
				holder.appendChild( n );
			}
		} );
	}
	function render( nodes ) {
		fill( app, [].concat( nodes ).filter( Boolean ) );
	}

	/** A WordPress-style notice at the top of the page. */
	function notify( message, isError ) {
		var box = document.getElementById( 'shyaka-messages' );
		var close = h( 'button', { type: 'button', className: 'notice-dismiss' }, h( 'span', { className: 'screen-reader-text' }, __( 'Dismiss this notice.', 'shyaka-for-woocommerce' ) ) );
		var note = h( 'div', { className: 'notice is-dismissible ' + ( isError ? 'notice-error' : 'notice-success' ) }, [ para( message ), close ] );
		close.addEventListener( 'click', function () {
			note.remove();
		} );
		fill( box, note );
	}

	function post( action, data ) {
		var body = new window.FormData();
		body.append( 'action', action );
		body.append( 'nonce', cfg.nonce );
		Object.keys( data || {} ).forEach( function ( k ) {
			body.append( k, data[ k ] === true ? '1' : data[ k ] === false ? '0' : String( data[ k ] ) );
		} );
		return window.fetch( cfg.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body } ).then( function ( r ) {
			return r.json().catch( function () {
				return {};
			} ).then( function ( json ) {
				if ( ! json || ! json.success ) {
					var msg = json && json.data && typeof json.data.message === 'string' ? json.data.message : __( 'Something went wrong. Reload the page and try again.', 'shyaka-for-woocommerce' );
					throw new Error( msg );
				}
				return json.data || {};
			} );
		} );
	}
	function server( op, extra ) {
		return post( 'shyaka_api', Object.assign( { op: op }, extra || {} ) );
	}
	function local( op, extra ) {
		return post( 'shyaka_local', Object.assign( { op: op }, extra || {} ) );
	}

	/** A button that shows a spinner while `work` runs and stops it however `work` ends. */
	function busy( btn, work ) {
		btn.addEventListener( 'click', function () {
			if ( btn.disabled ) {
				return;
			}
			btn.disabled = true;
			btn.classList.add( 'shyaka-busy' );
			Promise.resolve().then( work ).catch( function ( e ) {
				notify( e.message, true );
			} ).then( function () {
				btn.disabled = false;
				btn.classList.remove( 'shyaka-busy' );
			} );
		} );
		return btn;
	}

	/** Two or more buttons acting as one choice (the period on Results, the filter on Products). */
	function choice( options, selected, onPick ) {
		var buttons = options.map( function ( o ) {
			var b = button( o.label, o.value === selected, { 'aria-pressed': o.value === selected ? 'true' : 'false' } );
			b.addEventListener( 'click', function () {
				buttons.forEach( function ( x, i ) {
					var on = options[ i ].value === o.value;
					x.className = 'button' + ( on ? ' button-primary' : '' );
					x.setAttribute( 'aria-pressed', on ? 'true' : 'false' );
				} );
				onPick( o.value );
			} );
			return b;
		} );
		return h( 'div', { className: 'shyaka-choice', role: 'group' }, buttons );
	}

	function longDate( day ) {
		try {
			return new Date( String( day ).slice( 0, 10 ) + 'T00:00:00Z' ).toLocaleDateString( LOCALE, { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' } );
		} catch ( e ) {
			return String( day );
		}
	}
	function shortTime( iso ) {
		try {
			return new Date( iso ).toLocaleString( LOCALE, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' } );
		} catch ( e ) {
			return String( iso );
		}
	}
	function productCount( n ) {
		return sprintf( _n( '%d product', '%d products', n, 'shyaka-for-woocommerce' ), n );
	}

	// -----------------------------------------------------------------------------------------------------------
	// Where the store stands.
	function connected( s ) {
		return s.state && s.state !== 'none';
	}
	function linked( s ) {
		return s.state === 'linked' || s.state === 'checking' || s.state === 'rejected';
	}
	function businessStatus( s ) {
		if ( s.state === 'rejected' ) {
			return 'rejected';
		}
		if ( s.state === 'checking' ) {
			return 'pending';
		}
		return s.business && typeof s.business.status === 'string' ? s.business.status : 'approved';
	}
	/** How many products shoppers can see now (the server's count), or null when it didn't say. */
	function showing( s ) {
		if ( typeof s.shown === 'number' ) {
			return s.shown;
		}
		if ( typeof s.inShyaka === 'number' ) {
			return s.inShyaka;
		}
		if ( s.products && typeof s.products.showing === 'number' ) {
			return s.products.showing;
		}
		return null;
	}

	/** One badge, the same words in the header and in Settings. */
	function standing( s ) {
		if ( ! connected( s ) ) {
			return { tone: 'warning', label: __( 'Not connected', 'shyaka-for-woocommerce' ) };
		}
		if ( ! linked( s ) ) {
			return { tone: 'warning', label: __( 'Not linked yet', 'shyaka-for-woocommerce' ) };
		}
		var b = businessStatus( s );
		if ( b === 'rejected' || b === 'suspended' ) {
			return { tone: 'critical', label: __( 'Not approved', 'shyaka-for-woocommerce' ) };
		}
		if ( b !== 'approved' ) {
			return { tone: 'info', label: __( 'Shyaka is checking your business', 'shyaka-for-woocommerce' ) };
		}
		if ( showing( s ) === 0 ) {
			return { tone: 'attention', label: __( 'No products showing', 'shyaka-for-woocommerce' ) };
		}
		return { tone: 'success', label: __( 'Live in Shyaka', 'shyaka-for-woocommerce' ) };
	}

	function setStanding( s ) {
		var el = document.getElementById( 'shyaka-standing' );
		var st = standing( s );
		if ( el ) {
			el.className = 'shyaka-badge shyaka-badge--' + st.tone;
			el.textContent = st.label;
		}
	}

	function banner( tone, heading, children ) {
		return h( 'div', { className: 'shyaka-banner shyaka-banner--' + tone }, [ heading ? h( 'strong', {}, heading ) : null ].concat( children ) );
	}

	/** Shyaka's own review of a linked business: pending until approved, and a clear message when it was not approved. */
	function approvalBanner( s ) {
		if ( ! linked( s ) ) {
			return null;
		}
		var b = businessStatus( s );
		if ( b === 'approved' ) {
			return null;
		}
		if ( b === 'rejected' || b === 'suspended' ) {
			return banner( 'critical', __( 'Shyaka hasn’t approved your business', 'shyaka-for-woocommerce' ), [
				para( sprintf( __( 'Your products don’t show to shoppers in Shyaka. Write to %s and we’ll tell you why and what to change.', 'shyaka-for-woocommerce' ), cfg.email ) ),
			] );
		}
		return banner( 'info', __( 'Shyaka is checking your business', 'shyaka-for-woocommerce' ), [
			para( sprintf( __( 'Your products show to shoppers once Shyaka approves your business. You can choose products in the meantime. Questions: %s.', 'shyaka-for-woocommerce' ), cfg.email ) ),
		] );
	}

	// -----------------------------------------------------------------------------------------------------------
	// Connecting: WooCommerce's own approval screen ("Shyaka would like to connect to your store", read only).
	function connectForm( label, primary ) {
		var go = h( 'button', { type: 'submit', className: 'button' + ( primary ? ' button-primary' : '' ) }, label );
		var form = h( 'form', { method: 'post', action: cfg.connectUrl, className: 'shyaka-inline-form' }, [
			h( 'input', { type: 'hidden', name: 'action', value: 'shyaka_connect' } ),
			h( 'input', { type: 'hidden', name: '_wpnonce', value: cfg.connectNonce } ),
			go,
		] );
		form.addEventListener( 'submit', function () {
			go.disabled = true;
			go.classList.add( 'shyaka-busy' );
		} );
		return form;
	}

	function connectNotes() {
		var notes = [];
		if ( ! cfg.permalinks ) {
			notes.push( banner( 'warning', null, [
				para( __( 'WooCommerce’s approval screen needs pretty permalinks. Choose any option except Plain in Settings › Permalinks, then connect.', 'shyaka-for-woocommerce' ) ),
				row( [ linkButton( cfg.urls.permalinks, __( 'Open permalink settings', 'shyaka-for-woocommerce' ) ) ] ),
			] ) );
		}
		if ( ! cfg.https ) {
			notes.push( muted( __( 'Shyaka only connects to stores on a secure (https) address.', 'shyaka-for-woocommerce' ) ) );
		}
		return notes;
	}

	// -----------------------------------------------------------------------------------------------------------
	// Linking: a one-time code as a QR code for the iPhone camera, plus Open in Shyaka on an iPhone.
	function linkPanel( holder ) {
		return server( 'link' ).then( function ( r ) {
			var img = null;
			try {
				var qr = qrcode( 0, 'M' );
				qr.addData( r.link );
				qr.make();
				img = h( 'img', { src: qr.createDataURL( 6, 2 ), alt: __( 'Linking code for the Shyaka app', 'shyaka-for-woocommerce' ) } );
			} catch ( e ) {
				img = null;
			}
			fill( holder, h( 'div', { className: 'shyaka-qr' }, [
				img ? h( 'div', { className: 'shyaka-qr-code' }, img ) : null,
				h( 'div', { className: 'shyaka-qr-text' }, [
					h( 'ol', {}, [
						h( 'li', {}, __( 'Get Shyaka on your iPhone if you don’t have it yet.', 'shyaka-for-woocommerce' ) ),
						h( 'li', {}, IPHONE ? __( 'Tap Open in Shyaka, or scan this code with another iPhone.', 'shyaka-for-woocommerce' ) : __( 'Point your iPhone camera at this code.', 'shyaka-for-woocommerce' ) ),
						h( 'li', {}, __( 'Sign in, or let Shyaka make a business account from your store.', 'shyaka-for-woocommerce' ) ),
					] ),
					row( [
						IPHONE ? linkButton( r.link, __( 'Open in Shyaka', 'shyaka-for-woocommerce' ), true ) : null,
						linkButton( typeof r.appLink === 'string' ? r.appLink : cfg.urls.app, __( 'Get the iPhone app', 'shyaka-for-woocommerce' ), false, true ),
					] ),
					muted( __( 'This code works once, for 10 minutes. Make a new one any time.', 'shyaka-for-woocommerce' ) ),
				] ),
			] ) );
		} );
	}

	function linkBlock( label, primary ) {
		var holder = h( 'div', {} );
		var btn = busy( button( label, primary ), function () {
			return linkPanel( holder );
		} );
		return h( 'div', { className: 'shyaka-stack' }, [ row( [ btn ] ), holder ] );
	}

	// -----------------------------------------------------------------------------------------------------------
	// Home: the setup steps while any is open, then the last 7 days; the plan and the products on the side.
	function setupSteps( s ) {
		var steps = [
			{ done: true, title: __( 'Install Shyaka', 'shyaka-for-woocommerce' ) },
			{
				done: connected( s ),
				title: __( 'Connect your store', 'shyaka-for-woocommerce' ),
				body: __( 'WooCommerce asks you to give Shyaka read-only access. Its screen lists everything that access allows; Shyaka only reads your products. Shyaka never sees your WordPress password and can’t change anything in your store.', 'shyaka-for-woocommerce' ),
				action: h( 'div', { className: 'shyaka-stack' }, connectNotes().concat( [ row( [ connectForm( __( 'Connect to Shyaka', 'shyaka-for-woocommerce' ), true ) ] ) ] ) ),
			},
			{
				done: linked( s ),
				title: __( 'Link the Shyaka iPhone app', 'shyaka-for-woocommerce' ),
				body: __( 'Shoppers find your products through your business in the Shyaka iPhone app. Linking takes a minute on your phone.', 'shyaka-for-woocommerce' ),
				action: linkBlock( __( 'Show my linking code', 'shyaka-for-woocommerce' ), true ),
			},
			{
				done: cfg.listed > 0,
				title: __( 'Choose products for Shyaka', 'shyaka-for-woocommerce' ),
				body: __( 'Turn on Show in Shyaka here, on any product’s page, or for many products at once in the product list. Only published products that are in stock show.', 'shyaka-for-woocommerce' ),
				action: row( [ linkButton( cfg.urls.products, __( 'Choose products', 'shyaka-for-woocommerce' ), true ) ] ),
			},
		];
		var done = steps.filter( function ( x ) {
			return x.done;
		} ).length;
		if ( done === steps.length ) {
			return null;
		}
		var next = steps.filter( function ( x ) {
			return ! x.done;
		} )[ 0 ];
		return card( __( 'Set up Shyaka', 'shyaka-for-woocommerce' ), [
			muted( sprintf( __( '%1$d of %2$d done', 'shyaka-for-woocommerce' ), done, steps.length ) ),
			h( 'ol', { className: 'shyaka-steps' }, steps.map( function ( x ) {
				var open = x === next;
				return h( 'li', { className: x.done ? 'done' : open ? 'open' : '' }, [
					h( 'span', { className: 'mark', 'aria-hidden': 'true' }, x.done ? '✓' : '' ),
					h( 'div', {}, [
						h( 'strong', {}, x.title ),
						x.done ? h( 'span', { className: 'screen-reader-text' }, __( '(done)', 'shyaka-for-woocommerce' ) ) : null,
						open && x.body ? para( x.body ) : null,
						open && x.action ? x.action : null,
					] ),
				] );
			} ) ),
		] );
	}

	function change( now, before, days ) {
		if ( ! now && ! before ) {
			return { tone: '', label: '' };
		}
		var diff = now - before;
		if ( diff === 0 ) {
			return { tone: '', label: days === 7 ? __( 'Same as last week', 'shyaka-for-woocommerce' ) : __( 'Same as the 30 days before', 'shyaka-for-woocommerce' ) };
		}
		var label = days === 7
			? sprintf( diff > 0 ? __( '▲ %d on last week', 'shyaka-for-woocommerce' ) : __( '▼ %d on last week', 'shyaka-for-woocommerce' ), Math.abs( diff ) )
			: sprintf( diff > 0 ? __( '▲ %d on the 30 days before', 'shyaka-for-woocommerce' ) : __( '▼ %d on the 30 days before', 'shyaka-for-woocommerce' ), Math.abs( diff ) );
		return { tone: diff > 0 ? 'up' : 'down', label: label };
	}

	/** The four numbers shoppers make, the same on Home and Results. */
	function tiles( r, days ) {
		var p = r.previous || {};
		function tile( n, label, before ) {
			var c = change( n || 0, before || 0, days );
			return h( 'div', { className: 'shyaka-tile' }, [ h( 'span', { className: 'label' }, label ), h( 'span', { className: 'n' }, String( n || 0 ) ), h( 'span', { className: 'd ' + c.tone }, c.label ) ] );
		}
		return h( 'div', { className: 'shyaka-tiles' }, [
			tile( r.views, __( 'Views', 'shyaka-for-woocommerce' ), p.views ),
			tile( r.saved, __( 'Saves', 'shyaka-for-woocommerce' ), p.saved ),
			tile( r.closet, __( 'Added to closets', 'shyaka-for-woocommerce' ), p.closet ),
			tile( r.buy, __( 'Buy taps', 'shyaka-for-woocommerce' ), p.buy ),
		] );
	}

	function productTable( items ) {
		return h( 'table', { className: 'widefat striped shyaka-table' }, [
			h( 'thead', {}, h( 'tr', {}, [
				h( 'th', { scope: 'col' }, __( 'Product', 'shyaka-for-woocommerce' ) ),
				h( 'th', { scope: 'col', className: 'num' }, __( 'Views', 'shyaka-for-woocommerce' ) ),
				h( 'th', { scope: 'col', className: 'num' }, __( 'Closet adds', 'shyaka-for-woocommerce' ) ),
				h( 'th', { scope: 'col', className: 'num' }, __( 'Buy taps', 'shyaka-for-woocommerce' ) ),
			] ) ),
			h( 'tbody', {}, items.map( function ( i ) {
				return h( 'tr', {}, [ h( 'td', {}, String( i.title || '' ) ), h( 'td', { className: 'num' }, String( i.views || 0 ) ), h( 'td', { className: 'num' }, String( i.closet || 0 ) ), h( 'td', { className: 'num' }, String( i.buy || 0 ) ) ] );
			} ) ),
		] );
	}

	function weekSection( s ) {
		var holder = h( 'div', {}, spinner() );
		if ( ! linked( s ) ) {
			fill( holder, muted( __( 'Views, saves and Buy taps show here once your store is linked and shoppers find your products.', 'shyaka-for-woocommerce' ) ) );
		} else {
			server( 'stats', { days: 7 } ).then( function ( r ) {
				fill( holder, [
					tiles( r, 7 ),
					r.items && r.items.length
						? h( 'div', { className: 'shyaka-gap' }, [ h( 'h3', {}, __( 'Top products', 'shyaka-for-woocommerce' ) ), productTable( r.items.slice( 0, 3 ) ) ] )
						: muted( __( 'No activity in the last 7 days yet.', 'shyaka-for-woocommerce' ) ),
				] );
			} ).catch( function ( e ) {
				fill( holder, muted( e.message ) );
			} );
		}
		return card( __( 'Last 7 days', 'shyaka-for-woocommerce' ), [ holder, linked( s ) ? para( h( 'a', { href: cfg.urls.results }, __( 'See all results', 'shyaka-for-woocommerce' ) ) ) : null ] );
	}

	function planAside( s ) {
		var holder = h( 'div', {}, muted( __( 'Checking your plan…', 'shyaka-for-woocommerce' ) ) );
		if ( linked( s ) ) {
			server( 'plan' ).then( function ( p ) {
				var until = p.plan === 'founding' && p.onMarket && p.foundingUntil ? sprintf( __( 'Free until %s', 'shyaka-for-woocommerce' ), longDate( p.foundingUntil ) )
					: p.plan === 'none' || ! p.onMarket ? __( 'Your products aren’t showing in Shyaka.', 'shyaka-for-woocommerce' )
						: p.paidUntil ? sprintf( __( 'Paid until %s', 'shyaka-for-woocommerce' ), longDate( p.paidUntil ) ) : '';
				fill( holder, [
					para( h( 'strong', {}, p.plan === 'none' || ! p.label ? __( 'No plan', 'shyaka-for-woocommerce' ) : String( p.label ) ) ),
					until ? para( until ) : null,
					p.onMarket && typeof p.limit === 'number' ? muted( sprintf( __( '%1$s of %2$d in your plan', 'shyaka-for-woocommerce' ), productCount( p.listed || 0 ), p.limit ) ) : null,
					para( h( 'a', { href: cfg.urls.settings }, __( 'Manage plan', 'shyaka-for-woocommerce' ) ) ),
				] );
			} ).catch( function ( e ) {
				fill( holder, muted( e.message ) );
			} );
		} else {
			fill( holder, muted( __( 'Founding shops are free until 30 April 2027. Your plan shows here once your store is linked.', 'shyaka-for-woocommerce' ) ) );
		}
		return card( __( 'Plan', 'shyaka-for-woocommerce' ), [ holder ] );
	}

	function productsAside( s ) {
		var n = showing( s );
		return card( __( 'Products', 'shyaka-for-woocommerce' ), [
			para( sprintf( _n( '%d product set to show in Shyaka', '%d products set to show in Shyaka', cfg.listed, 'shyaka-for-woocommerce' ), cfg.listed ) ),
			linked( s ) && n !== null ? muted( sprintf( _n( '%d is showing to shoppers', '%d are showing to shoppers', n, 'shyaka-for-woocommerce' ), n ) ) : null,
			row( [ linkButton( cfg.urls.products, __( 'Choose products', 'shyaka-for-woocommerce' ) ) ] ),
		] );
	}

	function home( s ) {
		var banners = [ approvalBanner( s ) ];
		if ( s.syncState === 'failed' && typeof s.syncNote === 'string' ) {
			banners.push( banner( 'warning', null, [ para( s.syncNote ) ] ) );
		}
		var side = h( 'div', { className: 'shyaka-side' }, [ planAside( s ), productsAside( s ) ] );
		render( banners.concat( [ setupSteps( s ), h( 'div', { className: 'shyaka-home' }, [ weekSection( s ), side ] ) ] ) );
	}

	// -----------------------------------------------------------------------------------------------------------
	// Products: the store's products, with one switch each (the same setting as the tick on the product page).
	function syncButton() {
		return busy( button( __( 'Update now', 'shyaka-for-woocommerce' ) ), function () {
			return server( 'sync' ).then( function ( r ) {
				var n = typeof r.imported === 'number' ? r.imported : null;
				notify( n === null ? __( 'Shyaka is updating your products.', 'shyaka-for-woocommerce' ) : sprintf( _n( '%d product updated', '%d products updated', n, 'shyaka-for-woocommerce' ), n ) );
			} );
		} );
	}

	function products( s ) {
		var list = h( 'div', {} );
		var pager = h( 'div', { className: 'shyaka-pager' } );
		var countLine = h( 'strong', {} );
		var search = h( 'input', { type: 'search', className: 'regular-text', placeholder: __( 'Search by name', 'shyaka-for-woocommerce' ), 'aria-label': __( 'Search products', 'shyaka-for-woocommerce' ) } );
		var filter = 'all';
		var page = 1;
		var timer = null;
		var n = showing( s );

		function setCount() {
			countLine.textContent = sprintf( _n( '%d product set to show in Shyaka', '%d products set to show in Shyaka', cfg.listed, 'shyaka-for-woocommerce' ), cfg.listed );
		}

		function note( p ) {
			if ( p.type === 'external' || p.type === 'grouped' ) {
				return __( 'Shyaka shows simple and variable products only', 'shyaka-for-woocommerce' );
			}
			if ( p.status !== 'publish' ) {
				return __( 'Not published, so it won’t show', 'shyaka-for-woocommerce' );
			}
			if ( ! p.visible ) {
				return __( 'Hidden from your shop page, so it won’t show', 'shyaka-for-woocommerce' );
			}
			if ( ! p.inStock ) {
				return __( 'Out of stock, so it won’t show', 'shyaka-for-woocommerce' );
			}
			return '';
		}

		function productRow( p ) {
			var toggle = h( 'input', { type: 'checkbox', role: 'switch', className: 'shyaka-switch', 'aria-label': sprintf( __( 'Show %s in Shyaka', 'shyaka-for-woocommerce' ), p.title ) } );
			toggle.checked = !! p.listed;
			toggle.addEventListener( 'change', function () {
				var want = toggle.checked;
				toggle.disabled = true;
				local( 'set_listed', { id: p.id, listed: want } ).then( function ( r ) {
					p.listed = !! r.listed;
					cfg.listed = r.counts ? r.counts.listed : cfg.listed;
					setCount();
					notify( p.listed ? sprintf( __( '%s will show in Shyaka.', 'shyaka-for-woocommerce' ), p.title ) : sprintf( __( '%s is hidden from Shyaka.', 'shyaka-for-woocommerce' ), p.title ) );
				} ).catch( function ( e ) {
					notify( e.message, true );
				} ).then( function () {
					toggle.disabled = false;
					toggle.checked = !! p.listed;
				} );
			} );
			var why = note( p );
			return h( 'tr', {}, [
				h( 'td', { className: 'thumb' }, p.image ? h( 'img', { src: p.image, alt: '', width: 40, height: 40, loading: 'lazy' } ) : h( 'span', { className: 'shyaka-noimg', 'aria-hidden': 'true' } ) ),
				h( 'td', {}, [
					h( 'a', { href: p.edit, className: 'row-title' }, p.title ),
					p.price ? h( 'span', { className: 'shyaka-price' }, ' · ' + p.price ) : null,
					why ? muted( why ) : p.buy ? para( extLink( p.buy, __( 'Test the Buy button', 'shyaka-for-woocommerce' ) ) ) : null,
				] ),
				h( 'td', { className: 'switch' }, toggle ),
			] );
		}

		function load() {
			fill( list, spinner() );
			pager.textContent = '';
			local( 'products', { page: page, filter: filter, search: search.value || '' } ).then( function ( r ) {
				if ( ! r.items.length ) {
					fill( list, muted( search.value ? __( 'No products match that search.', 'shyaka-for-woocommerce' )
						: filter === 'in' ? __( 'None of your products are set to show in Shyaka yet.', 'shyaka-for-woocommerce' )
							: filter === 'out' ? __( 'Every one of your products is set to show in Shyaka.', 'shyaka-for-woocommerce' )
								: __( 'Your store has no products yet.', 'shyaka-for-woocommerce' ) ) );
					return;
				}
				fill( list, h( 'table', { className: 'widefat striped shyaka-table shyaka-products' }, [
					h( 'thead', {}, h( 'tr', {}, [
						h( 'th', { scope: 'col', className: 'thumb' }, h( 'span', { className: 'screen-reader-text' }, __( 'Image', 'shyaka-for-woocommerce' ) ) ),
						h( 'th', { scope: 'col' }, __( 'Product', 'shyaka-for-woocommerce' ) ),
						h( 'th', { scope: 'col', className: 'switch' }, __( 'In Shyaka', 'shyaka-for-woocommerce' ) ),
					] ) ),
					h( 'tbody', {}, r.items.map( productRow ) ),
				] ) );
				if ( r.pages > 1 ) {
					var prev = button( __( '‹ Previous', 'shyaka-for-woocommerce' ), false, { disabled: page <= 1 } );
					var next = button( __( 'Next ›', 'shyaka-for-woocommerce' ), false, { disabled: page >= r.pages } );
					prev.addEventListener( 'click', function () {
						page--;
						load();
					} );
					next.addEventListener( 'click', function () {
						page++;
						load();
					} );
					fill( pager, [ prev, h( 'span', {}, sprintf( __( 'Page %1$d of %2$d', 'shyaka-for-woocommerce' ), page, r.pages ) ), next ] );
				}
			} ).catch( function ( e ) {
				fill( list, muted( e.message ) );
			} );
		}
		search.addEventListener( 'input', function () {
			clearTimeout( timer );
			timer = setTimeout( function () {
				page = 1;
				load();
			}, 400 );
		} );

		var how = h( 'details', { className: 'shyaka-how' }, [
			h( 'summary', {}, __( 'How choosing works', 'shyaka-for-woocommerce' ) ),
			para( __( 'The switch here is the same as the Show in Shyaka tick on a product’s page (General tab). For many products at once, tick them in Products and choose Show in Shyaka or Hide from Shyaka under Bulk actions. Only published products that are visible in your shop and in stock appear in Shyaka. Changes reach Shyaka within a minute. Buy in Shyaka opens your checkout with the piece in the cart.', 'shyaka-for-woocommerce' ) ),
		] );

		setCount();
		render( [
			! linked( s ) ? banner( 'info', null, [ para( __( 'Shoppers see these products once your store is connected and you link the Shyaka iPhone app (see Home).', 'shyaka-for-woocommerce' ) ) ] ) : null,
			card( null, [
				h( 'div', { className: 'shyaka-summary' }, [
					h( 'div', {}, [
						countLine,
						linked( s ) && n !== null ? muted( sprintf( _n( '%d is showing to shoppers', '%d are showing to shoppers', n, 'shyaka-for-woocommerce' ), n ) + ( s.lastSyncedAt ? ' · ' + sprintf( __( 'updated %s', 'shyaka-for-woocommerce' ), shortTime( s.lastSyncedAt ) ) : '' ) ) : null,
					] ),
					row( [ connected( s ) ? syncButton() : null, linkButton( cfg.urls.wcProducts, __( 'Open WooCommerce products', 'shyaka-for-woocommerce' ) ) ] ),
				] ),
				how,
			] ),
			card( null, [
				h( 'div', { className: 'shyaka-toolbar' }, [
					choice( [ { value: 'all', label: __( 'All', 'shyaka-for-woocommerce' ) }, { value: 'in', label: __( 'In Shyaka', 'shyaka-for-woocommerce' ) }, { value: 'out', label: __( 'Not in Shyaka', 'shyaka-for-woocommerce' ) } ], 'all', function ( v ) {
						filter = v;
						page = 1;
						load();
					} ),
					h( 'div', { className: 'grow' }, search ),
				] ),
				list,
				pager,
			] ),
		] );
		load();
	}

	// -----------------------------------------------------------------------------------------------------------
	// Results: views, saves, closet adds and Buy taps (the same numbers as the iPhone app's Business screen).
	function results( s ) {
		var holder = h( 'div', {} );
		function show( days ) {
			fill( holder, spinner() );
			server( 'stats', { days: days } ).then( function ( r ) {
				fill( holder, [
					tiles( r, days ),
					r.items && r.items.length
						? h( 'div', { className: 'shyaka-gap' }, [ h( 'h3', {}, __( 'By product', 'shyaka-for-woocommerce' ) ), productTable( r.items ) ] )
						: muted( __( 'No activity in this period yet.', 'shyaka-for-woocommerce' ) ),
				] );
			} ).catch( function ( e ) {
				fill( holder, banner( 'critical', null, [ para( e.message ) ] ) );
			} );
		}
		var notes = muted( __( 'A view counts once per shopper per product per hour. Your own team is never counted. Sales are in your WooCommerce orders.', 'shyaka-for-woocommerce' ) );
		if ( ! linked( s ) ) {
			render( card( null, [ muted( __( 'Numbers appear once your store is linked and shoppers find your products.', 'shyaka-for-woocommerce' ) ), notes ] ) );
			return;
		}
		render( card( null, [ choice( [ { value: 7, label: __( 'Last 7 days', 'shyaka-for-woocommerce' ) }, { value: 30, label: __( 'Last 30 days', 'shyaka-for-woocommerce' ) } ], 7, show ), holder, notes ] ) );
		show( 7 );
	}

	// -----------------------------------------------------------------------------------------------------------
	// Settings: the plan, the Shyaka account, the storefront button, help, and disconnecting at the bottom.
	function price( x ) {
		if ( typeof x.price === 'string' && x.price ) {
			return x.price;
		}
		if ( typeof x.egp === 'number' ) {
			return sprintf( __( 'EGP %s', 'shyaka-for-woocommerce' ), x.egp.toLocaleString( LOCALE ) );
		}
		if ( typeof x.usd === 'number' ) {
			return '$' + x.usd;
		}
		return '';
	}

	function planBody( p, refresh ) {
		if ( p.linked === false ) {
			return [ para( __( 'Link your store to a Shyaka business first (see Home). Then choose a plan here.', 'shyaka-for-woocommerce' ) ) ];
		}
		var rows = [];
		var status;
		var label = String( p.label || '' );
		if ( p.status !== 'approved' && p.plan === 'founding' && p.foundingUntil ) {
			status = sprintf( __( 'Founding shop: free until %s. Your products show once Shyaka approves your business.', 'shyaka-for-woocommerce' ), longDate( p.foundingUntil ) );
		} else if ( p.status !== 'approved' ) {
			status = __( 'Your products show once Shyaka approves your business.', 'shyaka-for-woocommerce' );
		} else if ( p.plan === 'founding' ) {
			status = p.onMarket ? sprintf( __( 'Founding shop: free until %s.', 'shyaka-for-woocommerce' ), longDate( p.foundingUntil ) ) : __( 'Your free founding period has ended. Choose a plan to keep your products in Shyaka.', 'shyaka-for-woocommerce' );
		} else if ( p.plan === 'none' ) {
			status = __( 'No plan yet: your products aren’t showing in Shyaka.', 'shyaka-for-woocommerce' );
		} else if ( ! p.onMarket ) {
			status = sprintf( __( 'Your %s plan has ended: your products aren’t showing in Shyaka.', 'shyaka-for-woocommerce' ), label );
		} else {
			status = p.paidUntil ? sprintf( __( '%1$s plan, paid until %2$s.', 'shyaka-for-woocommerce' ), label, longDate( p.paidUntil ) ) : sprintf( __( '%s plan.', 'shyaka-for-woocommerce' ), label );
		}
		rows.push( para( status ) );
		if ( p.onMarket && typeof p.limit === 'number' ) {
			rows.push( muted( sprintf( __( '%1$s set to show in Shyaka; your plan shows up to %2$d.', 'shyaka-for-woocommerce' ), productCount( p.listed || 0 ), p.limit ) ) );
		}
		if ( ! p.canChoose ) {
			rows.push( muted( p.status !== 'approved' ? __( 'You can choose a plan once Shyaka has approved your business.', 'shyaka-for-woocommerce' ) : __( 'You can choose your plan from 30 days before your free period ends. Nothing is charged before then.', 'shyaka-for-woocommerce' ) ) );
		} else if ( p.chargesStartIn > 0 ) {
			rows.push( para( sprintf( _n( 'Choose now and your plan starts in %d day, when your free period ends.', 'Choose now and your plan starts in %d days, when your free period ends.', p.chargesStartIn, 'shyaka-for-woocommerce' ), p.chargesStartIn ) ) );
		}
		// The plans are always shown, so a shop knows the prices before it has to choose.
		rows.push( h( 'div', { className: 'shyaka-plans' }, ( p.plans || [] ).map( function ( x ) {
			var current = x.plan === p.plan && p.onMarket;
			var b = button( current ? __( 'Your plan', 'shyaka-for-woocommerce' ) : sprintf( __( 'Choose %s', 'shyaka-for-woocommerce' ), x.label ), x.plan === 'growth', { disabled: current || ! p.canChoose } );
			if ( p.canChoose && ! current ) {
				busy( b, function () {
					return server( 'subscribe', { plan: x.plan } ).then( function ( r ) {
						notify( typeof r.message === 'string' ? r.message : sprintf( __( 'You chose %s. Shyaka sends you an invoice; the plan starts once it is paid.', 'shyaka-for-woocommerce' ), x.label ) );
						refresh();
					} );
				} );
			}
			return h( 'div', { className: 'shyaka-plan' + ( current ? ' current' : '' ) }, [
				row( [ h( 'strong', {}, String( x.label ) ), x.plan === 'growth' ? badge( 'info', __( 'Most shops', 'shyaka-for-woocommerce' ) ) : null ] ),
				h( 'span', { className: 'price' }, price( x ) ),
				muted( __( 'every 30 days', 'shyaka-for-woocommerce' ) ),
				para( sprintf( __( 'Up to %d products in Shyaka', 'shyaka-for-woocommerce' ), x.products ) ),
				b,
			] );
		} ) ) );
		rows.push( muted( __( 'Paid plans are paid by invoice from Shyaka. Change or cancel any time. Cancelling keeps your products in Shyaka until the end of the period you paid for. Shyaka takes no commission on your sales.', 'shyaka-for-woocommerce' ) ) );
		if ( p.plan === 'starter' || p.plan === 'growth' || p.plan === 'pro' ) {
			var holder = h( 'div', {} );
			var stop = button( __( 'Cancel my plan', 'shyaka-for-woocommerce' ), false, { className: 'button shyaka-danger' } );
			stop.addEventListener( 'click', function () {
				var yes = busy( button( __( 'Yes, cancel', 'shyaka-for-woocommerce' ), true, { className: 'button button-primary shyaka-danger-primary' } ), function () {
					return server( 'cancelplan' ).then( function () {
						notify( __( 'Plan cancelled', 'shyaka-for-woocommerce' ) );
						refresh();
					} );
				} );
				var no = button( __( 'Keep my plan', 'shyaka-for-woocommerce' ) );
				no.addEventListener( 'click', function () {
					holder.textContent = '';
				} );
				fill( holder, banner( 'critical', __( 'Cancel your Shyaka plan?', 'shyaka-for-woocommerce' ), [
					para( sprintf( __( 'Your products stay in Shyaka until %s, then they stop showing.', 'shyaka-for-woocommerce' ), p.paidUntil ? longDate( p.paidUntil ) : __( 'the end of the period you paid for', 'shyaka-for-woocommerce' ) ) ),
					row( [ yes, no ] ),
				] ) );
			} );
			rows.push( holder, row( [ stop ] ) );
		}
		return rows;
	}

	function planSection() {
		var holder = h( 'div', {}, muted( __( 'Checking your plan…', 'shyaka-for-woocommerce' ) ) );
		function load() {
			server( 'plan' ).then( function ( p ) {
				fill( holder, h( 'div', { className: 'shyaka-stack' }, planBody( p, load ) ) );
			} ).catch( function ( e ) {
				fill( holder, para( e.message ) );
			} );
		}
		load();
		return card( __( 'Plan', 'shyaka-for-woocommerce' ), [ holder ] );
	}

	function accountSection( s ) {
		var st = standing( s );
		var isLinked = linked( s );
		var nodes = [ approvalBanner( s ) ];
		if ( ! connected( s ) ) {
			nodes.push(
				row( [ para( __( 'Your store isn’t connected to Shyaka yet.', 'shyaka-for-woocommerce' ) ), badge( st.tone, st.label ) ] ),
				typeof s.note === 'string' && s.note ? muted( s.note ) : null
			);
			nodes = nodes.concat( connectNotes(), [ row( [ connectForm( __( 'Connect to Shyaka', 'shyaka-for-woocommerce' ), true ) ] ) ] );
		} else {
			nodes.push(
				row( [ para( isLinked && s.business && s.business.name ? sprintf( __( 'Linked to the Shyaka business “%s”', 'shyaka-for-woocommerce' ), s.business.name ) : __( 'Connected. Not linked to a Shyaka business yet', 'shyaka-for-woocommerce' ) ), badge( st.tone, st.label ) ] ),
				muted( isLinked ? __( 'To move this store to a different Shyaka account, make a new linking code and scan it with that account’s iPhone.', 'shyaka-for-woocommerce' ) : __( 'Link the Shyaka iPhone app so shoppers can find your products.', 'shyaka-for-woocommerce' ) ),
				linkBlock( isLinked ? __( 'Link to another Shyaka account', 'shyaka-for-woocommerce' ) : __( 'Show my linking code', 'shyaka-for-woocommerce' ), ! isLinked )
			);
		}
		nodes.push( muted( __( 'Who can join: clothing, shoe and accessory shops selling to shoppers in Egypt. Linking needs the Shyaka iPhone app, and Shyaka checks each business before its products show. Founding shops are free until 30 April 2027. Shyaka takes no commission on your sales.', 'shyaka-for-woocommerce' ) ) );
		return card( __( 'Shyaka account', 'shyaka-for-woocommerce' ), [ h( 'div', { className: 'shyaka-stack' }, nodes ) ] );
	}

	function buttonSection() {
		var toggle = h( 'input', { type: 'checkbox', role: 'switch', className: 'shyaka-switch', id: 'shyaka-button-toggle' } );
		toggle.checked = !! cfg.button;
		toggle.addEventListener( 'change', function () {
			var want = toggle.checked;
			toggle.disabled = true;
			local( 'button', { on: want } ).then( function ( r ) {
				cfg.button = !! r.button;
				notify( cfg.button ? __( 'The Add to Shyaka closet button is on.', 'shyaka-for-woocommerce' ) : __( 'The Add to Shyaka closet button is off.', 'shyaka-for-woocommerce' ) );
			} ).catch( function ( e ) {
				notify( e.message, true );
			} ).then( function () {
				toggle.disabled = false;
				toggle.checked = !! cfg.button;
			} );
		} );
		return card( __( '“Add to Shyaka closet” button', 'shyaka-for-woocommerce' ), [ h( 'div', { className: 'shyaka-stack' }, [
			para( __( 'Optional. A button on your own product pages that lets shoppers save a product into their Shyaka closet.', 'shyaka-for-woocommerce' ) ),
			h( 'label', { className: 'shyaka-switch-label', for: 'shyaka-button-toggle' }, [ toggle, h( 'span', {}, __( 'Show the button on my product pages', 'shyaka-for-woocommerce' ) ) ] ),
			muted( __( 'It appears under Add to cart, only on products set to show in Shyaka. Turn it off here at any time.', 'shyaka-for-woocommerce' ) ),
		] ) ], { id: 'closet-button' } );
	}

	function helpSection() {
		return card( __( 'Help', 'shyaka-for-woocommerce' ), [
			para( __( 'Shyaka is an iPhone app where people keep their closet, plan outfits and find new pieces. Products you choose for Shyaka appear in its Market and on your shop page there. Shoppers can save them, add a product’s photo to their closet to style it with what they own, and tap Buy to go to your checkout. Payment, delivery and returns all happen in your own store.', 'shyaka-for-woocommerce' ) ),
			para( __( 'Shyaka reads your products (titles, descriptions, prices, photos, options and stock) and which ones you chose for Shyaka, with WooCommerce’s read-only approval. WooCommerce’s read-only access would also allow reading orders and customers; Shyaka never reads them, or your payments.', 'shyaka-for-woocommerce' ) ),
			row( [
				extLink( cfg.urls.support, __( 'Help and support', 'shyaka-for-woocommerce' ) ),
				h( 'a', { href: 'mailto:' + cfg.email }, cfg.email ),
				extLink( cfg.urls.privacy, __( 'Privacy policy', 'shyaka-for-woocommerce' ) ),
				extLink( cfg.urls.terms, __( 'Terms', 'shyaka-for-woocommerce' ) ),
			] ),
		] );
	}

	/** A button that asks before it acts. */
	function confirmed( label, heading, body, yesLabel, noLabel, work ) {
		var holder = h( 'div', {} );
		var first = button( label, false, { className: 'button shyaka-danger' } );
		first.addEventListener( 'click', function () {
			var yes = busy( button( yesLabel, true, { className: 'button button-primary shyaka-danger-primary' } ), work );
			var no = button( noLabel );
			no.addEventListener( 'click', function () {
				holder.textContent = '';
			} );
			fill( holder, banner( 'critical', heading, [ para( body ), row( [ yes, no ] ) ] ) );
		} );
		return h( 'div', { className: 'shyaka-stack' }, [ holder, row( [ first ] ) ] );
	}

	function disconnectSection( s ) {
		if ( ! connected( s ) ) {
			return card( __( 'Remove Shyaka', 'shyaka-for-woocommerce' ), [ muted( __( 'Your store isn’t connected, so Shyaka holds none of your products. To remove the plugin, deactivate and delete it in Plugins.', 'shyaka-for-woocommerce' ) ) ] );
		}
		var nodes = [];
		if ( linked( s ) ) {
			nodes.push(
				muted( __( 'Disconnecting removes your products from Shyaka and keeps your store connected, so you can link again later.', 'shyaka-for-woocommerce' ) ),
				confirmed( __( 'Disconnect from Shyaka', 'shyaka-for-woocommerce' ), __( 'Disconnect your store from Shyaka?', 'shyaka-for-woocommerce' ),
					__( 'Your products leave Shyaka straight away and shoppers can no longer find them. You can link again later. Your products in WooCommerce are not changed.', 'shyaka-for-woocommerce' ),
					__( 'Yes, disconnect', 'shyaka-for-woocommerce' ), __( 'Keep it', 'shyaka-for-woocommerce' ), function () {
						return server( 'unlink' ).then( function () {
							notify( __( 'Disconnected from Shyaka', 'shyaka-for-woocommerce' ) );
							start();
						} );
					} )
			);
		}
		nodes.push(
			muted( __( 'Removing the connection deletes everything Shyaka holds for your store: its read-only access, your products and any linking codes. Deactivating or deleting this plugin does the same.', 'shyaka-for-woocommerce' ) ),
			confirmed( __( 'Remove the connection', 'shyaka-for-woocommerce' ), __( 'Remove your store’s connection to Shyaka?', 'shyaka-for-woocommerce' ),
				__( 'Shyaka deletes your products and its access to your store. To use Shyaka again you connect and link again. Your products in WooCommerce are not changed.', 'shyaka-for-woocommerce' ),
				__( 'Yes, remove', 'shyaka-for-woocommerce' ), __( 'Keep it', 'shyaka-for-woocommerce' ), function () {
					return server( 'disconnect' ).then( function () {
						notify( __( 'Your store’s connection to Shyaka was removed.', 'shyaka-for-woocommerce' ) );
						cfg.connected = false;
						start();
					} );
				} )
		);
		return card( __( 'Disconnect', 'shyaka-for-woocommerce' ), [ h( 'div', { className: 'shyaka-stack' }, nodes ) ] );
	}

	function settings( s ) {
		var btn = buttonSection();
		render( [ linked( s ) ? planSection() : null, accountSection( s ), btn, helpSection(), disconnectSection( s ) ] );
		if ( window.location.hash === '#closet-button' ) {
			btn.scrollIntoView();
		}
	}

	// -----------------------------------------------------------------------------------------------------------
	function start() {
		server( 'status' ).then( function ( s ) {
			setStanding( s );
			var tab = app.getAttribute( 'data-tab' );
			if ( tab === 'products' ) {
				products( s );
			} else if ( tab === 'results' ) {
				results( s );
			} else if ( tab === 'settings' ) {
				settings( s );
			} else {
				home( s );
			}
		} ).catch( function ( e ) {
			render( banner( 'critical', __( 'Something went wrong', 'shyaka-for-woocommerce' ), [ para( e.message ) ] ) );
		} );
	}

	if ( cfg.connectError ) {
		notify( cfg.connectError, true );
	} else if ( cfg.returned === 'approved' ) {
		notify( __( 'Your store is connected. Next, link the Shyaka iPhone app.', 'shyaka-for-woocommerce' ) );
	} else if ( cfg.returned === 'declined' ) {
		notify( __( 'You didn’t approve the connection, so Shyaka can’t read your products. Connect again when you’re ready.', 'shyaka-for-woocommerce' ), true );
	}
	start();
}() );
